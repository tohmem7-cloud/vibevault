import { useState } from 'react';
import { ArrowLeft, CreditCard, Truck, Check, Lock } from 'lucide-react';
import { useCart, useNavigation } from '@/store';
import { formatPrice, generateOrderId, sendOrderEmail } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function Checkout() {
  const { cart, cartTotal, clearCart } = useCart();
  const { navigate } = useNavigation();
  
  const [step, setStep] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState('');
  
  const [shippingInfo, setShippingInfo] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    province: '',
    postalCode: '',
    phone: '',
  });
  
  const [paymentMethod, setPaymentMethod] = useState<'paypal' | 'card'>('paypal');

  if (cart.length === 0 && !orderComplete) {
    return (
      <div className="min-h-screen bg-black pt-24 pb-20 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl text-white mb-4">Your cart is empty</h1>
          <Button 
            onClick={() => navigate('shop')}
            className="bg-gradient-to-r from-purple-500 to-pink-500"
          >
            Continue Shopping
          </Button>
        </div>
      </div>
    );
  }

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
    window.scrollTo(0, 0);
  };

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const newOrderId = generateOrderId();
    setOrderId(newOrderId);
    
    sendOrderEmail({
      orderId: newOrderId,
      items: cart.map(item => ({
        name: item.product.name,
        quantity: item.quantity,
        price: item.product.price
      })),
      total: cartTotal,
      customerEmail: shippingInfo.email
    });
    
    setIsProcessing(false);
    setOrderComplete(true);
    clearCart();
  };

  if (orderComplete) {
    return (
      <div className="min-h-screen bg-black pt-24 pb-20">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="animate-scale-in">
            <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="h-12 w-12 text-green-400" />
            </div>
            <h1 className="text-3xl text-white font-medium mb-2">Order Confirmed!</h1>
            <p className="text-zinc-400 mb-6">
              Thank you for your order. We&apos;ve sent a confirmation to {shippingInfo.email}
            </p>
            <div className="bg-zinc-900 rounded-xl p-6 mb-8">
              <p className="text-zinc-400 text-sm">Order Number</p>
              <p className="text-white text-xl font-medium">{orderId}</p>
              <div className="mt-4 pt-4 border-t border-zinc-800">
                <p className="text-zinc-400 text-sm mb-2">Order Details</p>
                <p className="text-white">Total: {formatPrice(cartTotal)} CAD</p>
                <p className="text-zinc-400 text-sm mt-1">Shipping: FREE (Preorder)</p>
                <p className="text-purple-400 text-sm mt-2">Ships on February 23rd</p>
              </div>
            </div>
            <Button 
              onClick={() => navigate('shop')}
              className="bg-gradient-to-r from-purple-500 to-pink-500"
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4 mb-8">
          <button onClick={() => navigate('shop')} className="text-zinc-400 hover:text-white transition-colors">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h1 className="text-2xl text-white font-medium">Checkout</h1>
        </div>

        <div className="flex items-center gap-4 mb-12">
          <div className={`flex items-center gap-2 ${step >= 1 ? 'text-purple-400' : 'text-zinc-500'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-purple-500/20' : 'bg-zinc-800'}`}>
              <Truck className="h-4 w-4" />
            </div>
            <span className="text-sm hidden sm:inline">Shipping</span>
          </div>
          <div className="flex-1 h-px bg-zinc-800" />
          <div className={`flex items-center gap-2 ${step >= 2 ? 'text-purple-400' : 'text-zinc-500'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-purple-500/20' : 'bg-zinc-800'}`}>
              <CreditCard className="h-4 w-4" />
            </div>
            <span className="text-sm hidden sm:inline">Payment</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {step === 1 ? (
              <div className="bg-zinc-900 rounded-xl p-6 animate-slide-up">
                <h2 className="text-xl text-white font-medium mb-6">Shipping Information</h2>
                <form onSubmit={handleShippingSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-zinc-300">First Name</Label>
                      <Input
                        value={shippingInfo.firstName}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, firstName: e.target.value })}
                        className="bg-zinc-800 border-zinc-700 text-white"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-zinc-300">Last Name</Label>
                      <Input
                        value={shippingInfo.lastName}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, lastName: e.target.value })}
                        className="bg-zinc-800 border-zinc-700 text-white"
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-zinc-300">Email</Label>
                    <Input
                      type="email"
                      value={shippingInfo.email}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label className="text-zinc-300">Address</Label>
                    <Input
                      value={shippingInfo.address}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                      required
                    />
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <Label className="text-zinc-300">City</Label>
                      <Input
                        value={shippingInfo.city}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                        className="bg-zinc-800 border-zinc-700 text-white"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-zinc-300">Province</Label>
                      <Input
                        value={shippingInfo.province}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, province: e.target.value })}
                        className="bg-zinc-800 border-zinc-700 text-white"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-zinc-300">Postal Code</Label>
                      <Input
                        value={shippingInfo.postalCode}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, postalCode: e.target.value })}
                        className="bg-zinc-800 border-zinc-700 text-white"
                        required
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-zinc-300">Phone</Label>
                    <Input
                      type="tel"
                      value={shippingInfo.phone}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white"
                      required
                    />
                  </div>
                  
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 py-6"
                  >
                    Continue to Payment
                  </Button>
                </form>
              </div>
            ) : (
              <div className="bg-zinc-900 rounded-xl p-6 animate-slide-up">
                <h2 className="text-xl text-white font-medium mb-6">Payment Method</h2>
                
                <div className="space-y-4 mb-6">
                  <button
                    onClick={() => setPaymentMethod('paypal')}
                    className={`w-full p-4 rounded-lg border-2 flex items-center gap-4 transition-colors ${
                      paymentMethod === 'paypal'
                        ? 'border-purple-500 bg-purple-500/10'
                        : 'border-zinc-700 hover:border-zinc-600'
                    }`}
                  >
                    <div className="w-12 h-8 bg-blue-600 rounded flex items-center justify-center text-white text-xs font-bold">
                      PayPal
                    </div>
                    <div className="flex-1 text-left">
                      <p className="text-white font-medium">PayPal</p>
                      <p className="text-zinc-400 text-sm">Pay with your PayPal account</p>
                    </div>
                    {paymentMethod === 'paypal' && <Check className="h-5 w-5 text-purple-400" />}
                  </button>
                  
                  <button
                    onClick={() => setPaymentMethod('card')}
                    className={`w-full p-4 rounded-lg border-2 flex items-center gap-4 transition-colors ${
                      paymentMethod === 'card'
                        ? 'border-purple-500 bg-purple-500/10'
                        : 'border-zinc-700 hover:border-zinc-600'
                    }`}
                  >
                    <CreditCard className="h-8 w-8 text-zinc-400" />
                    <div className="flex-1 text-left">
                      <p className="text-white font-medium">Credit/Debit Card</p>
                      <p className="text-zinc-400 text-sm">Pay with Visa, Mastercard, etc.</p>
                    </div>
                    {paymentMethod === 'card' && <Check className="h-5 w-5 text-purple-400" />}
                  </button>
                </div>

                {paymentMethod === 'paypal' && (
                  <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg mb-6">
                    <p className="text-blue-300 text-sm">
                      You will be redirected to PayPal to complete your payment.
                    </p>
                    <p className="text-zinc-400 text-sm mt-1">
                      PayPal: <a href="https://paypal.me/MTohme222" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">paypal.me/MTohme222</a>
                    </p>
                  </div>
                )}

                {paymentMethod === 'card' && (
                  <form className="space-y-4 mb-6">
                    <div>
                      <Label className="text-zinc-300">Card Number</Label>
                      <Input
                        placeholder="1234 5678 9012 3456"
                        className="bg-zinc-800 border-zinc-700 text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-zinc-300">Expiry Date</Label>
                        <Input
                          placeholder="MM/YY"
                          className="bg-zinc-800 border-zinc-700 text-white"
                        />
                      </div>
                      <div>
                        <Label className="text-zinc-300">CVV</Label>
                        <Input
                          placeholder="123"
                          className="bg-zinc-800 border-zinc-700 text-white"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-zinc-300">Cardholder Name</Label>
                      <Input
                        placeholder="Name on card"
                        className="bg-zinc-800 border-zinc-700 text-white"
                      />
                    </div>
                  </form>
                )}

                <div className="flex gap-4">
                  <Button
                    onClick={() => setStep(1)}
                    variant="outline"
                    className="flex-1 border-zinc-700 text-white hover:bg-zinc-800"
                  >
                    Back
                  </Button>
                  <Button
                    onClick={handlePaymentSubmit}
                    disabled={isProcessing}
                    className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 py-6"
                  >
                    {isProcessing ? 'Processing...' : `Pay ${formatPrice(cartTotal)}`}
                  </Button>
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-zinc-900 rounded-xl p-6 sticky top-24">
              <h2 className="text-xl text-white font-medium mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6">
                {cart.map((item, index) => (
                  <div key={index} className="flex gap-4">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <p className="text-white text-sm line-clamp-1">{item.product.name}</p>
                      <p className="text-zinc-400 text-xs">Qty: {item.quantity}</p>
                      <p className="text-zinc-400 text-xs">Size: {item.size}</p>
                    </div>
                    <p className="text-white text-sm">
                      {formatPrice(item.product.price * item.quantity)}
                    </p>
                  </div>
                ))}
              </div>
              
              <div className="space-y-2 pt-6 border-t border-zinc-800">
                <div className="flex justify-between text-zinc-400">
                  <span>Subtotal</span>
                  <span>{formatPrice(cartTotal)}</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Shipping</span>
                  <span className="text-green-400">FREE</span>
                </div>
                <div className="flex justify-between text-zinc-400">
                  <span>Tax</span>
                  <span>{formatPrice(cartTotal * 0.13)}</span>
                </div>
                <div className="flex justify-between text-white text-lg font-medium pt-4 border-t border-zinc-800">
                  <span>Total</span>
                  <span>{formatPrice(cartTotal * 1.13)}</span>
                </div>
              </div>
              
              <div className="mt-6 p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <div className="flex items-center gap-2 text-purple-400 mb-1">
                  <Truck className="h-4 w-4" />
                  <span className="text-sm font-medium">Preorder</span>
                </div>
                <p className="text-zinc-400 text-xs">
                  Ships on February 23rd with FREE shipping
                </p>
              </div>
              
              <div className="mt-4 flex items-center gap-2 text-zinc-500 text-xs">
                <Lock className="h-4 w-4" />
                <span>Secure checkout</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
