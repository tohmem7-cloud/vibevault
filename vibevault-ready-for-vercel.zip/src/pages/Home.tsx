import { useState, useEffect, useRef } from 'react';
import { ArrowRight, Sparkles, Truck, Shield, Clock, Zap, TrendingUp, Star } from 'lucide-react';
import { products } from '@/data/products';
import { useCart, useNavigation } from '@/store';
import { formatPrice } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const featuredProducts = products.filter(p => p.isBestseller).slice(0, 4);
const newArrivals = products.filter(p => p.isNew).slice(0, 4);

export default function Home() {
  const { addToCart } = useCart();
  const { navigate } = useNavigation();
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (heroRef.current) {
        const scrolled = window.scrollY;
        heroRef.current.style.transform = `translateY(${scrolled * 0.5}px)`;
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleQuickAdd = (product: typeof products[0]) => {
    addToCart({
      product,
      quantity: 1,
      size: product.sizes[0],
      color: product.colors[0].name,
      ml: product.mlOptions?.[0]
    });
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <section className="relative h-screen overflow-hidden">
        <div
          ref={heroRef}
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1556906781-9a412961c28c?w=1920&q=80')`,
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black" />
        </div>

        <div className="relative z-10 h-full flex flex-col items-center justify-center text-center px-4">
          <div className="animate-slide-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/20 rounded-full border border-purple-500/30 mb-6">
              <Sparkles className="h-4 w-4 text-purple-400" />
              <span className="text-purple-300 text-sm">Preorder Now - Ships Feb 23</span>
            </div>
          </div>

          <h1 className="animate-slide-up font-display text-6xl sm:text-8xl lg:text-9xl tracking-wider bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent">
            VIBEVAULT
          </h1>

          <p className="animate-slide-up mt-4 text-xl sm:text-2xl text-zinc-300 max-w-2xl">
            Premium Streetwear & Sneakers
          </p>

          <p className="animate-slide-up mt-2 text-zinc-400">
            Curated drops from Off-White, Supreme, Fear of God & more
          </p>

          <div className="animate-slide-up mt-8 flex flex-col sm:flex-row gap-4">
            <Button
              onClick={() => navigate('shop')}
              size="lg"
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-8 py-6 text-lg font-medium"
            >
              Shop Collection
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button
              onClick={() => navigate('shop')}
              size="lg"
              variant="outline"
              className="border-zinc-600 text-white hover:bg-zinc-800 px-8 py-6 text-lg"
            >
              View Hoodies
            </Button>
          </div>

          <div className="animate-slide-up mt-12 flex items-center gap-6 text-zinc-400 text-sm">
            <div className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              <span>Free Shipping on Preorders</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>Ships Feb 23</span>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-zinc-600 rounded-full flex justify-center">
            <div className="w-1.5 h-3 bg-purple-500 rounded-full mt-2 animate-pulse" />
          </div>
        </div>
      </section>

      {/* Features Bar */}
      <section className="py-8 bg-zinc-900/50 border-y border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Truck, text: 'Free Shipping on Preorders' },
              { icon: Shield, text: '100% Authentic Products' },
              { icon: Clock, text: 'Ships February 23' },
              { icon: Zap, text: 'Limited Drops' },
            ].map((feature, index) => (
              <div key={index} className="flex items-center gap-3">
                <feature.icon className="h-5 w-5 text-purple-400" />
                <span className="text-zinc-300 text-sm">{feature.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="font-display text-4xl sm:text-5xl text-white">Featured Collection</h2>
              <p className="mt-2 text-zinc-400">Our most popular items</p>
            </div>
            <button 
              onClick={() => navigate('shop')}
              className="hidden sm:flex items-center text-purple-400 hover:text-purple-300 transition-colors"
            >
              View All <ArrowRight className="ml-2 h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product, index) => (
              <div
                key={product.id}
                className="group animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative bg-zinc-900 rounded-xl overflow-hidden">
                  {product.isPreorder && (
                    <div className="absolute top-3 left-3 z-10 px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-medium rounded-full">
                      Preorder
                    </div>
                  )}
                  {product.isBestseller && (
                    <div className="absolute top-3 right-3 z-10 px-3 py-1 bg-amber-500/80 text-white text-xs font-medium rounded-full flex items-center gap-1">
                      <Star className="h-3 w-3" />
                      Bestseller
                    </div>
                  )}

                  <button onClick={() => navigate('product')} className="w-full">
                    <div className="aspect-[3/4] overflow-hidden">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                  </button>

                  <button
                    onClick={() => handleQuickAdd(product)}
                    className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300"
                  >
                    <Button className="w-full bg-white text-black hover:bg-zinc-200">
                      Quick Add
                    </Button>
                  </button>
                </div>

                <div className="mt-4">
                  <p className="text-zinc-500 text-sm">{product.brand}</p>
                  <button onClick={() => navigate('product')}>
                    <h3 className="text-white font-medium group-hover:text-purple-400 transition-colors line-clamp-1 text-left">
                      {product.name}
                    </h3>
                  </button>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-white font-medium">{formatPrice(product.price)}</span>
                    <span className="text-zinc-500 text-sm">CAD</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    <Star className="h-3 w-3 text-amber-400 fill-amber-400" />
                    <span className="text-zinc-400 text-sm">{product.rating}</span>
                    <span className="text-zinc-600 text-sm">({product.reviewCount})</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-20 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="font-display text-4xl sm:text-5xl text-white text-center mb-12">
            Shop by Category
          </h2>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { name: 'Hoodies', image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=600&q=80' },
              { name: 'Pants', image: 'https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?w=600&q=80' },
              { name: 'Tracksuits', image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80' },
              { name: 'Colognes', image: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?w=600&q=80' },
            ].map((category) => (
              <button
                key={category.name}
                onClick={() => navigate('shop')}
                className="group block relative overflow-hidden rounded-xl"
              >
                <div className="aspect-[4/5]">
                  <img
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-display text-2xl text-white group-hover:text-purple-400 transition-colors text-left">
                    {category.name}
                  </h3>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-5 w-5 text-purple-400" />
                <span className="text-purple-400 text-sm">New Drops</span>
              </div>
              <h2 className="font-display text-4xl sm:text-5xl text-white">New Arrivals</h2>
            </div>
            <button 
              onClick={() => navigate('shop')}
              className="hidden sm:flex items-center text-purple-400 hover:text-purple-300 transition-colors"
            >
              View All <ArrowRight className="ml-2 h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.map((product, index) => (
              <div
                key={product.id}
                className="group animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative bg-zinc-900 rounded-xl overflow-hidden">
                  <div className="absolute top-3 left-3 z-10 px-3 py-1 bg-green-500 text-white text-xs font-medium rounded-full">
                    New
                  </div>
                  <button onClick={() => navigate('product')} className="w-full">
                    <div className="aspect-[3/4] overflow-hidden">
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    </div>
                  </button>
                </div>
                <div className="mt-4">
                  <p className="text-zinc-500 text-sm">{product.brand}</p>
                  <button onClick={() => navigate('product')}>
                    <h3 className="text-white font-medium group-hover:text-purple-400 transition-colors line-clamp-1 text-left">
                      {product.name}
                    </h3>
                  </button>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-white font-medium">{formatPrice(product.price)}</span>
                    <span className="text-zinc-500 text-sm">CAD</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Preorder Banner */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative rounded-2xl overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-600" />
            <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg width=\'60\' height=\'60\' viewBox=\'0 0 60 60\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg fill=\'none\' fill-rule=\'evenodd\'%3E%3Cg fill=\'%23ffffff\' fill-opacity=\'0.1\'%3E%3Cpath d=\'M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")' }} />
            
            <div className="relative z-10 px-8 py-16 sm:px-16 sm:py-20 text-center">
              <Sparkles className="h-12 w-12 text-white mx-auto mb-6" />
              <h2 className="font-display text-4xl sm:text-6xl text-white mb-4">
                PREORDER NOW
              </h2>
              <p className="text-white/80 text-lg max-w-2xl mx-auto mb-2">
                Due to Chinese New Year, all orders will ship on February 23rd
              </p>
              <p className="text-white/60 text-sm max-w-2xl mx-auto mb-8">
                14-day shipping • FREE shipping on all preorders
              </p>
              <Button
                onClick={() => navigate('shop')}
                size="lg"
                className="bg-white text-purple-600 hover:bg-zinc-100 px-8 py-6 text-lg font-medium"
              >
                Shop Preorders
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Request Section */}
      <section id="request-section" className="py-20 bg-zinc-900/30">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-display text-4xl sm:text-5xl text-white mb-4">
            Looking for Something Specific?
          </h2>
          <p className="text-zinc-400 mb-8">
            Can&apos;t find what you&apos;re looking for? Submit a request and we&apos;ll help you find it.
          </p>
          <RequestForm />
        </div>
      </section>
    </div>
  );
}

function RequestForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    item: '',
    description: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setSubmitted(true);
    toast.success('Request submitted! Check your email for confirmation.');
  };

  if (submitted) {
    return (
      <div className="bg-zinc-800/50 rounded-xl p-8">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Sparkles className="h-8 w-8 text-green-400" />
          </div>
          <h3 className="text-white text-xl font-medium mb-2">Thanks for your request!</h3>
          <p className="text-zinc-400 mb-2">
            Please wait 5 hours for a response.
          </p>
          <p className="text-zinc-500 text-sm">
            An email will be sent to <span className="text-purple-400">tohmem7@gmail.com</span> with the estimated price and details.
          </p>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <input
          type="text"
          placeholder="Your Name"
          value={formData.name}
          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          className="w-full bg-zinc-800 text-white px-4 py-3 rounded-lg border border-zinc-700 focus:border-purple-500 transition-colors"
          required
        />
        <input
          type="email"
          placeholder="Your Email"
          value={formData.email}
          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          className="w-full bg-zinc-800 text-white px-4 py-3 rounded-lg border border-zinc-700 focus:border-purple-500 transition-colors"
          required
        />
      </div>
      <input
        type="text"
        placeholder="Item Name (e.g., Nike Air Force 1 White)"
        value={formData.item}
        onChange={(e) => setFormData({ ...formData, item: e.target.value })}
        className="w-full bg-zinc-800 text-white px-4 py-3 rounded-lg border border-zinc-700 focus:border-purple-500 transition-colors"
        required
      />
      <textarea
        placeholder="Additional details (size, color, condition preference, etc.)"
        value={formData.description}
        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
        rows={4}
        className="w-full bg-zinc-800 text-white px-4 py-3 rounded-lg border border-zinc-700 focus:border-purple-500 transition-colors resize-none"
      />
      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6"
      >
        {isSubmitting ? 'Submitting...' : 'Submit Request'}
      </Button>
    </form>
  );
}
