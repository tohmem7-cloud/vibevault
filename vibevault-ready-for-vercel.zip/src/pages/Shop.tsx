import { useState, useMemo } from 'react';
import { Filter, Star } from 'lucide-react';
import { products, brands, categories } from '@/data/products';
import { useCart, useFilters, useNavigation } from '@/store';
import { formatPrice, filterProducts } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { toast } from 'sonner';

export default function Shop() {
  const { addToCart } = useCart();
  const { filters, updateFilters, resetFilters } = useFilters();
  const { navigate } = useNavigation();
  
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = useMemo(() => {
    return filterProducts(products, {
      ...filters,
      searchQuery: searchQuery || undefined,
    });
  }, [filters, searchQuery]);

  const handleQuickAdd = (product: typeof products[0]) => {
    addToCart({
      product,
      quantity: 1,
      size: product.sizes[0],
      color: product.colors[0].name,
      ml: product.mlOptions?.[0]
    });
    toast.success(`${product.name} added to cart!`);
  };

  const clearAllFilters = () => {
    resetFilters();
    setSearchQuery('');
  };

  const activeFiltersCount = 
    filters.brands.length + 
    filters.categories.length + 
    filters.sizes.length + 
    filters.colors.length +
    (filters.priceRange[0] > 0 || filters.priceRange[1] < 1000 ? 1 : 0);

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display text-4xl sm:text-5xl text-white mb-2">
            All Products
          </h1>
          <p className="text-zinc-400">
            {filteredProducts.length} products available
          </p>
        </div>

        {/* Filters Bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8 py-4 border-y border-zinc-800">
          <div className="flex items-center gap-4">
            <Sheet open={isFilterOpen} onOpenChange={setIsFilterOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
                  <Filter className="h-4 w-4 mr-2" />
                  Filters
                  {activeFiltersCount > 0 && (
                    <span className="ml-2 bg-purple-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {activeFiltersCount}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="bg-zinc-900 border-zinc-800 w-full sm:max-w-md overflow-y-auto">
                <SheetHeader>
                  <SheetTitle className="text-white">Filters</SheetTitle>
                </SheetHeader>
                <FilterContent
                  filters={filters}
                  updateFilters={updateFilters}
                  onClear={clearAllFilters}
                />
              </SheetContent>
            </Sheet>

            {activeFiltersCount > 0 && (
              <button
                onClick={clearAllFilters}
                className="text-zinc-400 hover:text-white text-sm flex items-center gap-1"
              >
                Clear all
              </button>
            )}
          </div>

          <div className="flex items-center gap-4">
            <Select
              value={filters.sortBy}
              onValueChange={(value) => updateFilters({ sortBy: value as any })}
            >
              <SelectTrigger className="w-40 bg-zinc-900 border-zinc-700 text-white">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-zinc-900 border-zinc-800">
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Active Filters */}
        {activeFiltersCount > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {filters.brands.map((brand) => (
              <span
                key={brand}
                className="inline-flex items-center gap-1 px-3 py-1 bg-zinc-800 text-white text-sm rounded-full"
              >
                {brand}
                <button
                  onClick={() => updateFilters({ brands: filters.brands.filter(b => b !== brand) })}
                  className="hover:text-red-400"
                >
                  ×
                </button>
              </span>
            ))}
            {filters.categories.map((cat) => (
              <span
                key={cat}
                className="inline-flex items-center gap-1 px-3 py-1 bg-zinc-800 text-white text-sm rounded-full"
              >
                {cat}
                <button
                  onClick={() => updateFilters({ categories: filters.categories.filter(c => c !== cat) })}
                  className="hover:text-red-400"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        )}

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product, index) => (
            <div
              key={product.id}
              className="group animate-fade-in"
              style={{ animationDelay: `${index * 0.05}s` }}
            >
              <div className="relative bg-zinc-900 rounded-xl overflow-hidden">
                <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
                  {product.isPreorder && (
                    <span className="px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-medium rounded-full">
                      Preorder
                    </span>
                  )}
                  {product.isNew && (
                    <span className="px-3 py-1 bg-green-500 text-white text-xs font-medium rounded-full">
                      New
                    </span>
                  )}
                </div>
                {product.isBestseller && (
                  <div className="absolute top-3 right-3 z-10 px-3 py-1 bg-amber-500/80 text-white text-xs font-medium rounded-full flex items-center gap-1">
                    <Star className="h-3 w-3" />
                    Bestseller
                  </div>
                )}

                <button onClick={() => navigate('product')} className="w-full">
                  <div className="aspect-[3/4] overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </button>

                <button
                  onClick={() => handleQuickAdd(product)}
                  className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300"
                >
                  <Button className="w-full bg-white text-black hover:bg-zinc-200">
                    Quick Add
                  </Button>
                </button>
              </div>

              <div className="mt-4">
                <p className="text-zinc-500 text-sm">{product.brand}</p>
                <button onClick={() => navigate('product')}>
                  <h3 className="text-white font-medium group-hover:text-purple-400 transition-colors line-clamp-1 text-left">
                    {product.name}
                  </h3>
                </button>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-white font-medium">{formatPrice(product.price)}</span>
                  <span className="text-zinc-500 text-sm">CAD</span>
                </div>
                <div className="flex items-center gap-1 mt-1">
                  <Star className="h-3 w-3 text-amber-400 fill-amber-400" />
                  <span className="text-zinc-400 text-sm">{product.rating}</span>
                  <span className="text-zinc-600 text-sm">({product.reviewCount})</span>
                </div>
                {product.stockCount < 10 && (
                  <p className="text-red-400 text-xs mt-1">Only {product.stockCount} left</p>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20">
            <p className="text-zinc-400 text-lg">No products found</p>
            <button
              onClick={clearAllFilters}
              className="mt-4 text-purple-400 hover:text-purple-300"
            >
              Clear filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function FilterContent({
  filters,
  updateFilters,
  onClear,
}: {
  filters: any;
  updateFilters: (f: any) => void;
  onClear: () => void;
}) {
  const allSizes = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '28', '30', '32', '34', '36', '38', '40'];
  const allColors = ['Black', 'White', 'Gray', 'Blue', 'Navy', 'Red', 'Pink', 'Brown'];

  return (
    <div className="space-y-8 py-4">
      <div>
        <h3 className="text-white font-medium mb-4">Categories</h3>
        <div className="space-y-2">
          {categories.map((cat) => (
            <label key={cat.id} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={filters.categories.includes(cat.id)}
                onCheckedChange={(checked) => {
                  updateFilters({
                    categories: checked
                      ? [...filters.categories, cat.id]
                      : filters.categories.filter((c: string) => c !== cat.id),
                  });
                }}
                className="border-zinc-600 data-[state=checked]:bg-purple-500"
              />
              <span className="text-zinc-300 text-sm">{cat.name}</span>
              <span className="text-zinc-500 text-xs">({cat.count})</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-white font-medium mb-4">Brands</h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {brands.map((brand) => (
            <label key={brand} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={filters.brands.includes(brand)}
                onCheckedChange={(checked) => {
                  updateFilters({
                    brands: checked
                      ? [...filters.brands, brand]
                      : filters.brands.filter((b: string) => b !== brand),
                  });
                }}
                className="border-zinc-600 data-[state=checked]:bg-purple-500"
              />
              <span className="text-zinc-300 text-sm">{brand}</span>
            </label>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-white font-medium mb-4">Price Range</h3>
        <Slider
          value={filters.priceRange}
          onValueChange={(value) => updateFilters({ priceRange: value })}
          max={500}
          step={10}
          className="mb-4"
        />
        <div className="flex justify-between text-zinc-400 text-sm">
          <span>{formatPrice(filters.priceRange[0])}</span>
          <span>{formatPrice(filters.priceRange[1])}</span>
        </div>
      </div>

      <div>
        <h3 className="text-white font-medium mb-4">Sizes</h3>
        <div className="flex flex-wrap gap-2">
          {allSizes.map((size) => (
            <button
              key={size}
              onClick={() => {
                updateFilters({
                  sizes: filters.sizes.includes(size)
                    ? filters.sizes.filter((s: string) => s !== size)
                    : [...filters.sizes, size],
                });
              }}
              className={`px-3 py-1 text-sm rounded border transition-colors ${
                filters.sizes.includes(size)
                  ? 'bg-purple-500 border-purple-500 text-white'
                  : 'border-zinc-600 text-zinc-300 hover:border-zinc-500'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-white font-medium mb-4">Colors</h3>
        <div className="space-y-2">
          {allColors.map((color) => (
            <label key={color} className="flex items-center gap-2 cursor-pointer">
              <Checkbox
                checked={filters.colors.includes(color)}
                onCheckedChange={(checked) => {
                  updateFilters({
                    colors: checked
                      ? [...filters.colors, color]
                      : filters.colors.filter((c: string) => c !== color),
                  });
                }}
                className="border-zinc-600 data-[state=checked]:bg-purple-500"
              />
              <span className="text-zinc-300 text-sm">{color}</span>
            </label>
          ))}
        </div>
      </div>

      <Button
        onClick={onClear}
        variant="outline"
        className="w-full border-zinc-700 text-white hover:bg-zinc-800"
      >
        Clear All Filters
      </Button>
    </div>
  );
}
