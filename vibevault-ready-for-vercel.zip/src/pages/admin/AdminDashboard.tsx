import { useState, useMemo } from 'react';
import { 
  Package, 
  ShoppingCart, 
  TrendingUp, 
  DollarSign,
  Users,
  BarChart3,
  Activity
} from 'lucide-react';
import { useStore, useNavigation } from '@/store';
import { products } from '@/data/products';
import { formatPrice } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from 'recharts';

export default function AdminDashboard() {
  const { navigate } = useNavigation();
  const { state } = useStore();
  const [timeRange, setTimeRange] = useState('7d');

  // Calculate REAL stats from actual orders
  const realStats = useMemo(() => {
    const orders = state.orders;
    
    // Total Revenue - sum of all order totals
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
    
    // Total Orders count
    const totalOrders = orders.length;
    
    // Unique customers (based on email)
    const uniqueCustomers = new Set(orders.map(o => o.customerEmail)).size;
    
    // Calculate daily sales for the chart (last 7 days)
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      return date.toISOString().split('T')[0];
    });
    
    const salesData = last7Days.map(date => {
      const dayOrders = orders.filter(o => o.createdAt.startsWith(date));
      const dayRevenue = dayOrders.reduce((sum, o) => sum + o.total, 0);
      return {
        name: new Date(date).toLocaleDateString('en-US', { weekday: 'short' }),
        sales: dayRevenue,
        orders: dayOrders.length
      };
    });
    
    // Calculate category breakdown from orders
    const categoryBreakdown: Record<string, number> = {};
    orders.forEach(order => {
      order.items.forEach(item => {
        const cat = item.product.category;
        categoryBreakdown[cat] = (categoryBreakdown[cat] || 0) + (item.product.price * item.quantity);
      });
    });
    
    const categoryData = [
      { name: 'Hoodies', value: Math.round((categoryBreakdown['hoodies'] || 0)) },
      { name: 'Pants', value: Math.round((categoryBreakdown['pants'] || 0)) },
      { name: 'Tracksuits', value: Math.round((categoryBreakdown['tracksuits'] || 0)) },
      { name: 'Colognes', value: Math.round((categoryBreakdown['colognes'] || 0)) },
    ].filter(c => c.value > 0);
    
    return {
      totalRevenue,
      totalOrders,
      uniqueCustomers,
      salesData,
      categoryData
    };
  }, [state.orders]);

  const stats = [
    {
      title: 'Total Revenue',
      value: formatPrice(realStats.totalRevenue),
      change: realStats.totalOrders > 0 ? 'Active' : 'No sales yet',
      trend: 'up',
      icon: DollarSign,
      color: 'from-green-500 to-emerald-500'
    },
    {
      title: 'Total Orders',
      value: realStats.totalOrders.toString(),
      change: realStats.totalOrders === 1 ? '1 order placed' : `${realStats.totalOrders} orders placed`,
      trend: 'up',
      icon: ShoppingCart,
      color: 'from-purple-500 to-pink-500'
    },
    {
      title: 'Products',
      value: products.length.toString(),
      change: 'In stock',
      trend: 'up',
      icon: Package,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'Customers',
      value: realStats.uniqueCustomers.toString(),
      change: realStats.uniqueCustomers === 1 ? '1 unique customer' : `${realStats.uniqueCustomers} unique customers`,
      trend: 'up',
      icon: Users,
      color: 'from-amber-500 to-orange-500'
    },
  ];

  const quickActions = [
    { name: 'Manage Products', page: 'admin-products', icon: Package, color: 'bg-purple-500' },
    { name: 'View Orders', page: 'admin-orders', icon: ShoppingCart, color: 'bg-pink-500' },
    { name: 'Market Trends', page: 'admin-market', icon: TrendingUp, color: 'bg-blue-500' },
    { name: 'Trade Recommendations', page: 'admin-trade', icon: BarChart3, color: 'bg-green-500' },
  ];

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl text-white font-medium">Admin Dashboard</h1>
            <p className="text-zinc-400">Welcome back, Administrator</p>
          </div>
          <div className="flex gap-2">
            {['24h', '7d', '30d', '90d'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-4 py-2 rounded-lg text-sm transition-colors ${
                  timeRange === range
                    ? 'bg-purple-500 text-white'
                    : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                }`}
              >
                {range}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div
              key={stat.title}
              className="bg-zinc-900 rounded-xl p-6 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-zinc-400 text-sm">{stat.title}</p>
                  <p className="text-2xl text-white font-medium mt-1">{stat.value}</p>
                  <div className="flex items-center gap-1 mt-2 text-zinc-500">
                    <span className="text-xs">{stat.change}</span>
                  </div>
                </div>
                <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
                  <stat.icon className="h-5 w-5 text-white" />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mb-8">
          <h2 className="text-xl text-white font-medium mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action) => (
              <button
                key={action.name}
                onClick={() => navigate(action.page)}
                className="bg-zinc-900 rounded-xl p-6 hover:bg-zinc-800 transition-colors group text-left"
              >
                <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <action.icon className="h-6 w-6 text-white" />
                </div>
                <p className="text-white font-medium">{action.name}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-zinc-900 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl text-white font-medium">Sales Overview (Last 7 Days)</h2>
              <Activity className="h-5 w-5 text-zinc-400" />
            </div>
            <div className="h-64">
              {realStats.totalOrders > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={realStats.salesData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="name" stroke="#666" />
                    <YAxis stroke="#666" tickFormatter={(value) => `$${value}`} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a1a', border: 'none', borderRadius: '8px' }}
                      labelStyle={{ color: '#fff' }}
                      formatter={(value: number) => [`$${value.toFixed(2)}`, 'Revenue']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="sales" 
                      stroke="#8b5cf6" 
                      strokeWidth={2}
                      dot={{ fill: '#8b5cf6' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-zinc-500">
                  <div className="text-center">
                    <Activity className="h-12 w-12 mx-auto mb-2 text-zinc-600" />
                    <p>No sales data yet</p>
                    <p className="text-sm">Orders will appear here when customers make purchases</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="bg-zinc-900 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl text-white font-medium">Sales by Category</h2>
              <BarChart3 className="h-5 w-5 text-zinc-400" />
            </div>
            <div className="h-64">
              {realStats.categoryData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={realStats.categoryData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="name" stroke="#666" />
                    <YAxis stroke="#666" tickFormatter={(value) => `$${value}`} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a1a', border: 'none', borderRadius: '8px' }}
                      labelStyle={{ color: '#fff' }}
                      formatter={(value: number) => [`$${value.toFixed(2)}`, 'Revenue']}
                    />
                    <Bar dataKey="value" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full text-zinc-500">
                  <div className="text-center">
                    <BarChart3 className="h-12 w-12 mx-auto mb-2 text-zinc-600" />
                    <p>No category data yet</p>
                    <p className="text-sm">Sales by category will appear here</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl text-white font-medium">Recent Orders</h2>
            <Button 
              onClick={() => navigate('admin-orders')}
              variant="outline" 
              className="border-zinc-700 text-white hover:bg-zinc-800"
            >
              View All
            </Button>
          </div>
          
          {state.orders.length === 0 ? (
            <div className="text-center py-8">
              <ShoppingCart className="h-12 w-12 text-zinc-600 mx-auto mb-4" />
              <p className="text-zinc-400">No orders yet</p>
              <p className="text-zinc-500 text-sm mt-1">Orders will appear here when customers make purchases</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-zinc-800">
                    <th className="text-left text-zinc-400 text-sm font-medium py-3">Order ID</th>
                    <th className="text-left text-zinc-400 text-sm font-medium py-3">Customer</th>
                    <th className="text-left text-zinc-400 text-sm font-medium py-3">Date</th>
                    <th className="text-left text-zinc-400 text-sm font-medium py-3">Status</th>
                    <th className="text-right text-zinc-400 text-sm font-medium py-3">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {state.orders.slice(0, 5).map((order) => (
                    <tr key={order.id} className="border-b border-zinc-800/50">
                      <td className="py-4 text-white">{order.id}</td>
                      <td className="py-4 text-zinc-400">{order.customerEmail}</td>
                      <td className="py-4 text-zinc-400">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-4">
                        <span className={`px-3 py-1 rounded-full text-xs ${
                          order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                          order.status === 'shipped' ? 'bg-blue-500/20 text-blue-400' :
                          'bg-amber-500/20 text-amber-400'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="py-4 text-right text-white">{formatPrice(order.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
