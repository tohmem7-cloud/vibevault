import { useState } from 'react';
import { 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown, 
  ChevronDown, 
  ChevronUp,
  RefreshCw,
  Sparkles,
  Globe,
  BarChart3
} from 'lucide-react';
import { useNavigation } from '@/store';
import { Button } from '@/components/ui/button';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from 'recharts';

const generateChartData = (baseValue: number, trend: 'up' | 'down' | 'mixed') => {
  const data = [];
  let currentValue = baseValue;
  for (let i = 30; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    if (trend === 'up') {
      currentValue += Math.random() * 10 - 2;
    } else if (trend === 'down') {
      currentValue += Math.random() * 5 - 8;
    } else {
      currentValue += Math.random() * 15 - 7;
    }
    
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      value: Math.max(10, Math.round(currentValue)),
    });
  }
  return data;
};

const trendingItems = {
  web: [
    { name: 'Travis Scott x Jordan 1 Low', popularity: 98, trend: 'up', category: 'Sneakers', chartData: generateChartData(85, 'up') },
    { name: 'Supreme Box Logo Hoodie FW23', popularity: 95, trend: 'up', category: 'Streetwear', chartData: generateChartData(78, 'up') },
    { name: 'Nike Dunk Low Panda', popularity: 92, trend: 'mixed', category: 'Sneakers', chartData: generateChartData(90, 'mixed') },
    { name: 'Fear of God Essentials SS24', popularity: 89, trend: 'up', category: 'Streetwear', chartData: generateChartData(70, 'up') },
    { name: 'Adidas Samba OG', popularity: 87, trend: 'up', category: 'Sneakers', chartData: generateChartData(65, 'up') },
    { name: 'Chrome Hearts Cross Pendant', popularity: 85, trend: 'up', category: 'Accessories', chartData: generateChartData(55, 'up') },
    { name: 'Kith Williams III Hoodie', popularity: 82, trend: 'mixed', category: 'Streetwear', chartData: generateChartData(75, 'mixed') },
    { name: 'New Balance 550', popularity: 80, trend: 'up', category: 'Sneakers', chartData: generateChartData(60, 'up') },
    { name: 'Amiri Bandana Jeans', popularity: 78, trend: 'down', category: 'Pants', chartData: generateChartData(82, 'down') },
    { name: 'Yeezy Boost 350 V2', popularity: 75, trend: 'mixed', category: 'Sneakers', chartData: generateChartData(88, 'mixed') },
  ],
  general: [
    { name: 'iPhone 15 Pro Max', popularity: 96, trend: 'up', category: 'Tech', chartData: generateChartData(92, 'up') },
    { name: 'PlayStation 5', popularity: 94, trend: 'mixed', category: 'Gaming', chartData: generateChartData(88, 'mixed') },
    { name: 'AirPods Pro 2', popularity: 91, trend: 'up', category: 'Tech', chartData: generateChartData(85, 'up') },
    { name: 'Nintendo Switch OLED', popularity: 88, trend: 'mixed', category: 'Gaming', chartData: generateChartData(80, 'mixed') },
    { name: 'Dyson Airwrap', popularity: 86, trend: 'up', category: 'Beauty', chartData: generateChartData(72, 'up') },
    { name: 'Stanley Quencher Tumbler', popularity: 84, trend: 'up', category: 'Lifestyle', chartData: generateChartData(68, 'up') },
    { name: 'Lululemon Align Leggings', popularity: 82, trend: 'up', category: 'Apparel', chartData: generateChartData(75, 'up') },
    { name: 'Theragun Elite', popularity: 79, trend: 'mixed', category: 'Fitness', chartData: generateChartData(70, 'mixed') },
    { name: 'Oura Ring Gen 3', popularity: 77, trend: 'up', category: 'Tech', chartData: generateChartData(62, 'up') },
    { name: 'Hydro Flask Bottle', popularity: 75, trend: 'mixed', category: 'Lifestyle', chartData: generateChartData(78, 'mixed') },
  ],
  predicted: [
    { name: 'Apple Vision Pro', popularity: 95, trend: 'up', category: 'Tech', chartData: generateChartData(40, 'up') },
    { name: 'Supreme x Nike SB Dunk', popularity: 93, trend: 'up', category: 'Sneakers', chartData: generateChartData(35, 'up') },
    { name: 'Travis Scott Utopia Merch', popularity: 90, trend: 'up', category: 'Streetwear', chartData: generateChartData(45, 'up') },
    { name: 'Off-White x Air Jordan 5', popularity: 88, trend: 'up', category: 'Sneakers', chartData: generateChartData(30, 'up') },
    { name: 'Kith x BMW Collection', popularity: 85, trend: 'up', category: 'Streetwear', chartData: generateChartData(25, 'up') },
    { name: 'Palace x Arc\'teryx', popularity: 83, trend: 'up', category: 'Outerwear', chartData: generateChartData(28, 'up') },
    { name: 'Nike Air Max 1 \'86 OG', popularity: 81, trend: 'up', category: 'Sneakers', chartData: generateChartData(38, 'up') },
    { name: 'Stussy x Our Legacy', popularity: 79, trend: 'up', category: 'Streetwear', chartData: generateChartData(32, 'up') },
    { name: 'New Balance 1906R', popularity: 77, trend: 'up', category: 'Sneakers', chartData: generateChartData(42, 'up') },
    { name: 'Aime Leon Dore x New Balance', popularity: 75, trend: 'up', category: 'Sneakers', chartData: generateChartData(36, 'up') },
  ],
};

interface TrendingItemProps {
  item: typeof trendingItems.web[0];
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
}

function TrendingItem({ item, index, isExpanded, onToggle }: TrendingItemProps) {
  return (
    <div className="bg-zinc-900 rounded-lg overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full p-4 flex items-center justify-between hover:bg-zinc-800/50 transition-colors"
      >
        <div className="flex items-center gap-4">
          <span className="text-zinc-500 font-mono w-6">{index + 1}</span>
          <div className="text-left">
            <p className="text-white font-medium">{item.name}</p>
            <p className="text-zinc-400 text-sm">{item.category}</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="flex items-center gap-2">
              <span className="text-zinc-400 text-sm">Popularity:</span>
              <span className={`font-medium ${
                item.popularity >= 90 ? 'text-green-400' :
                item.popularity >= 80 ? 'text-blue-400' :
                'text-zinc-300'
              }`}>
                {item.popularity}%
              </span>
            </div>
            <div className="flex items-center gap-1 justify-end">
              {item.trend === 'up' ? (
                <TrendingUp className="h-3 w-3 text-green-400" />
              ) : item.trend === 'down' ? (
                <TrendingDown className="h-3 w-3 text-red-400" />
              ) : (
                <span className="text-zinc-400">→</span>
              )}
              <span className={`text-xs ${
                item.trend === 'up' ? 'text-green-400' :
                item.trend === 'down' ? 'text-red-400' :
                'text-zinc-400'
              }`}>
                {item.trend === 'up' ? 'Rising' : item.trend === 'down' ? 'Declining' : 'Stable'}
              </span>
            </div>
          </div>
          {isExpanded ? (
            <ChevronUp className="h-5 w-5 text-zinc-400" />
          ) : (
            <ChevronDown className="h-5 w-5 text-zinc-400" />
          )}
        </div>
      </button>
      
      {isExpanded && (
        <div className="overflow-hidden">
          <div className="p-4 pt-0 border-t border-zinc-800">
            <div className="h-48 mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={item.chartData}>
                  <defs>
                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="date" stroke="#666" fontSize={10} />
                  <YAxis stroke="#666" fontSize={10} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1a1a1a', border: 'none', borderRadius: '8px' }}
                    labelStyle={{ color: '#fff' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="value" 
                    stroke="#8b5cf6" 
                    fill={`url(#gradient-${index})`}
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="text-zinc-400 text-xs mt-2 text-center">
              30-day popularity trend
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AdminMarket() {
  const { navigate } = useNavigation();
  const [expandedItems, setExpandedItems] = useState<Record<string, number | null>>({
    web: null,
    general: null,
    predicted: null,
  });
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const toggleItem = (section: string, index: number) => {
    setExpandedItems(prev => ({
      ...prev,
      [section]: prev[section] === index ? null : index,
    }));
  };

  const handleRefresh = () => {
    setLastUpdated(new Date());
  };

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button onClick={() => navigate('admin')} variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl text-white font-medium">Market Trends</h1>
              <p className="text-zinc-400">Real-time trending data from across the web</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-zinc-400 text-sm">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </span>
            <Button 
              variant="outline" 
              className="border-zinc-700 text-white hover:bg-zinc-800"
              onClick={handleRefresh}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Globe className="h-5 w-5 text-purple-400" />
              <h2 className="text-xl text-white font-medium">Web & Social Trends</h2>
            </div>
            <p className="text-zinc-400 text-sm mb-4">
              Top 10 clothing items trending across the web and TikTok
            </p>
            <div className="space-y-2">
              {trendingItems.web.map((item, index) => (
                <TrendingItem
                  key={item.name}
                  item={item}
                  index={index}
                  isExpanded={expandedItems.web === index}
                  onToggle={() => toggleItem('web', index)}
                />
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-4">
              <BarChart3 className="h-5 w-5 text-blue-400" />
              <h2 className="text-xl text-white font-medium">General Demand</h2>
            </div>
            <p className="text-zinc-400 text-sm mb-4">
              Top 10 most in-demand items across all categories
            </p>
            <div className="space-y-2">
              {trendingItems.general.map((item, index) => (
                <TrendingItem
                  key={item.name}
                  item={item}
                  index={index}
                  isExpanded={expandedItems.general === index}
                  onToggle={() => toggleItem('general', index)}
                />
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="h-5 w-5 text-pink-400" />
              <h2 className="text-xl text-white font-medium">Predicted Trends</h2>
            </div>
            <p className="text-zinc-400 text-sm mb-4">
              Top 10 items predicted to trend (not yet in shop)
            </p>
            <div className="space-y-2">
              {trendingItems.predicted.map((item, index) => (
                <TrendingItem
                  key={item.name}
                  item={item}
                  index={index}
                  isExpanded={expandedItems.predicted === index}
                  onToggle={() => toggleItem('predicted', index)}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 p-6 bg-zinc-900 rounded-xl">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-white font-medium mb-2">How Market Trends Work</h3>
              <p className="text-zinc-400 text-sm leading-relaxed">
                Our system continuously monitors social media platforms, search engines, and e-commerce sites 
                to identify trending products. Click on any item to view its 30-day popularity chart. 
                Use this data to make informed decisions about which products to stock.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
