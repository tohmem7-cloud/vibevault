import { useState } from 'react';
import { 
  ArrowLeft, 
  TrendingUp, 
  DollarSign, 
  Bitcoin,
  Briefcase,
  AlertTriangle,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { useNavigation } from '@/store';
import { Button } from '@/components/ui/button';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

const generatePerformanceData = (baseReturn: number) => {
  const data = [];
  let value = 100;
  for (let i = 365; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    const dailyChange = (baseReturn / 365) + (Math.random() - 0.5) * 2;
    value *= (1 + dailyChange / 100);
    
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      value: Math.round(value * 100) / 100,
    });
  }
  return data;
};

const tradeRecommendations = [
  {
    symbol: 'BTC',
    name: 'Bitcoin',
    type: 'crypto' as const,
    currentPrice: 52134,
    potentialReturn: 25,
    risk: 'high' as const,
    reasoning: 'Historical Q1 performance shows 20-30% gains. Halving event approaching in April 2024. Institutional adoption continues to grow.',
    performanceData: generatePerformanceData(25),
  },
  {
    symbol: 'ETH',
    name: 'Ethereum',
    type: 'crypto' as const,
    currentPrice: 2891,
    potentialReturn: 20,
    risk: 'high' as const,
    reasoning: 'Strong DeFi ecosystem growth. ETF approval potential in 2024. Staking rewards provide passive income.',
    performanceData: generatePerformanceData(20),
  },
  {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    type: 'stock' as const,
    currentPrice: 185.92,
    potentialReturn: 12,
    risk: 'low' as const,
    reasoning: 'Stable dividend stock with consistent growth. AI integration with Apple Intelligence. Strong balance sheet.',
    performanceData: generatePerformanceData(12),
  },
  {
    symbol: 'NVDA',
    name: 'NVIDIA',
    type: 'stock' as const,
    currentPrice: 726.13,
    potentialReturn: 35,
    risk: 'medium' as const,
    reasoning: 'AI chip demand continues to surge. Data center growth strong. Leading position in GPU market.',
    performanceData: generatePerformanceData(35),
  },
  {
    symbol: 'GOOGL',
    name: 'Alphabet',
    type: 'stock' as const,
    currentPrice: 141.80,
    potentialReturn: 15,
    risk: 'low' as const,
    reasoning: 'Search dominance + cloud growth. Undervalued compared to peers. AI advancements with Gemini.',
    performanceData: generatePerformanceData(15),
  },
  {
    symbol: 'MSFT',
    name: 'Microsoft',
    type: 'stock' as const,
    currentPrice: 413.64,
    potentialReturn: 18,
    risk: 'low' as const,
    reasoning: 'Azure growth + AI integration via Copilot. Stable enterprise business. Strong recurring revenue.',
    performanceData: generatePerformanceData(18),
  },
  {
    symbol: 'AMZN',
    name: 'Amazon',
    type: 'stock' as const,
    currentPrice: 170.00,
    potentialReturn: 22,
    risk: 'medium' as const,
    reasoning: 'AWS recovery + retail efficiency improvements. Advertising business growing rapidly.',
    performanceData: generatePerformanceData(22),
  },
  {
    symbol: 'TSLA',
    name: 'Tesla',
    type: 'stock' as const,
    currentPrice: 193.57,
    potentialReturn: 30,
    risk: 'high' as const,
    reasoning: 'FSD progress + energy business growth. Cybertruck production ramping. Volatile but high potential.',
    performanceData: generatePerformanceData(30),
  },
  {
    symbol: 'SOL',
    name: 'Solana',
    type: 'crypto' as const,
    currentPrice: 108.45,
    potentialReturn: 40,
    risk: 'high' as const,
    reasoning: 'Fastest growing L1 blockchain. Strong DeFi and NFT ecosystem. Low transaction fees.',
    performanceData: generatePerformanceData(40),
  },
  {
    symbol: 'META',
    name: 'Meta Platforms',
    type: 'stock' as const,
    currentPrice: 474.99,
    potentialReturn: 20,
    risk: 'medium' as const,
    reasoning: 'Metaverse bet + AI integration. Cost cutting improving margins. Instagram Reels competing with TikTok.',
    performanceData: generatePerformanceData(20),
  },
];

const getRiskColor = (risk: string) => {
  switch (risk) {
    case 'low':
      return 'text-green-400 bg-green-500/20';
    case 'medium':
      return 'text-amber-400 bg-amber-500/20';
    case 'high':
      return 'text-red-400 bg-red-500/20';
    default:
      return 'text-zinc-400 bg-zinc-500/20';
  }
};

const getRiskLabel = (risk: string) => {
  switch (risk) {
    case 'low':
      return 'Low Risk';
    case 'medium':
      return 'Medium Risk';
    case 'high':
      return 'High Risk';
    default:
      return risk;
  }
};

export default function AdminTrade() {
  const { navigate } = useNavigation();
  const [selectedAsset, setSelectedAsset] = useState<typeof tradeRecommendations[0] | null>(null);
  const [filter, setFilter] = useState<'all' | 'crypto' | 'stock'>('all');
  const [lastUpdated, setLastUpdated] = useState(new Date());

  const filteredAssets = tradeRecommendations.filter(asset => 
    filter === 'all' || asset.type === filter
  );

  const handleRefresh = () => {
    setLastUpdated(new Date());
  };

  const totalPotentialReturn = filteredAssets.reduce((sum, asset) => sum + asset.potentialReturn, 0) / filteredAssets.length;

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button onClick={() => navigate('admin')} variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl text-white font-medium">Trade Recommendations</h1>
              <p className="text-zinc-400">Top investment opportunities based on market analysis</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-zinc-400 text-sm">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </span>
            <Button 
              variant="outline" 
              className="border-zinc-700 text-white hover:bg-zinc-800"
              onClick={handleRefresh}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="bg-zinc-900 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <TrendingUp className="h-5 w-5 text-purple-400" />
              </div>
              <span className="text-zinc-400">Avg. Potential Return</span>
            </div>
            <p className="text-3xl text-white font-medium">+{totalPotentialReturn.toFixed(1)}%</p>
          </div>
          
          <div className="bg-zinc-900 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Briefcase className="h-5 w-5 text-blue-400" />
              </div>
              <span className="text-zinc-400">Stocks</span>
            </div>
            <p className="text-3xl text-white font-medium">
              {tradeRecommendations.filter(a => a.type === 'stock').length}
            </p>
          </div>
          
          <div className="bg-zinc-900 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-amber-500/20 rounded-lg">
                <Bitcoin className="h-5 w-5 text-amber-400" />
              </div>
              <span className="text-zinc-400">Crypto</span>
            </div>
            <p className="text-3xl text-white font-medium">
              {tradeRecommendations.filter(a => a.type === 'crypto').length}
            </p>
          </div>
        </div>

        <div className="flex gap-2 mb-6">
          {(['all', 'crypto', 'stock'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                filter === f
                  ? 'bg-purple-500 text-white'
                  : 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800'
              }`}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h2 className="text-xl text-white font-medium mb-4">Top 10 Recommendations</h2>
            {filteredAssets.map((asset) => (
              <div
                key={asset.symbol}
                onClick={() => setSelectedAsset(asset)}
                className={`bg-zinc-900 rounded-xl p-4 cursor-pointer transition-all hover:bg-zinc-800 ${
                  selectedAsset?.symbol === asset.symbol ? 'ring-2 ring-purple-500' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      asset.type === 'crypto' ? 'bg-amber-500/20' : 'bg-blue-500/20'
                    }`}>
                      {asset.type === 'crypto' ? (
                        <Bitcoin className="h-5 w-5 text-amber-400" />
                      ) : (
                        <Briefcase className="h-5 w-5 text-blue-400" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-white font-medium">{asset.symbol}</span>
                        <span className="text-zinc-400 text-sm">{asset.name}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className={`px-2 py-0.5 rounded text-xs ${getRiskColor(asset.risk)}`}>
                          {getRiskLabel(asset.risk)}
                        </span>
                        <span className="text-green-400 text-sm">+{asset.potentialReturn}%</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-white font-medium">
                      ${asset.currentPrice.toLocaleString()}
                    </p>
                    <p className="text-zinc-400 text-sm">Current Price</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div>
            <h2 className="text-xl text-white font-medium mb-4">Asset Details</h2>
            {selectedAsset ? (
              <div className="bg-zinc-900 rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-4">
                    <div className={`w-14 h-14 rounded-xl flex items-center justify-center ${
                      selectedAsset.type === 'crypto' ? 'bg-amber-500/20' : 'bg-blue-500/20'
                    }`}>
                      {selectedAsset.type === 'crypto' ? (
                        <Bitcoin className="h-7 w-7 text-amber-400" />
                      ) : (
                        <Briefcase className="h-7 w-7 text-blue-400" />
                      )}
                    </div>
                    <div>
                      <h3 className="text-2xl text-white font-medium">{selectedAsset.symbol}</h3>
                      <p className="text-zinc-400">{selectedAsset.name}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl text-white font-medium">
                      ${selectedAsset.currentPrice.toLocaleString()}
                    </p>
                    <p className="text-green-400">+{selectedAsset.potentialReturn}% potential</p>
                  </div>
                </div>

                <div className="h-48 mb-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={selectedAsset.performanceData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                      <XAxis dataKey="date" stroke="#666" fontSize={10} />
                      <YAxis stroke="#666" fontSize={10} domain={['auto', 'auto']} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#1a1a1a', border: 'none', borderRadius: '8px' }}
                        labelStyle={{ color: '#fff' }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="value" 
                        stroke="#8b5cf6" 
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="h-4 w-4 text-purple-400" />
                      <span className="text-white font-medium">Analysis</span>
                    </div>
                    <p className="text-zinc-400 text-sm leading-relaxed">
                      {selectedAsset.reasoning}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-zinc-800 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <TrendingUp className="h-4 w-4 text-green-400" />
                        <span className="text-zinc-400 text-sm">Potential Return</span>
                      </div>
                      <p className="text-green-400 text-xl font-medium">+{selectedAsset.potentialReturn}%</p>
                    </div>
                    <div className="bg-zinc-800 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <AlertTriangle className="h-4 w-4 text-amber-400" />
                        <span className="text-zinc-400 text-sm">Risk Level</span>
                      </div>
                      <p className={`text-xl font-medium capitalize ${
                        selectedAsset.risk === 'low' ? 'text-green-400' :
                        selectedAsset.risk === 'medium' ? 'text-amber-400' :
                        'text-red-400'
                      }`}>
                        {selectedAsset.risk}
                      </p>
                    </div>
                  </div>

                  <a
                    href={selectedAsset.type === 'crypto' 
                      ? `https://coinmarketcap.com/currencies/${selectedAsset.name.toLowerCase().replace(/\s+/g, '-')}`
                      : `https://finance.yahoo.com/quote/${selectedAsset.symbol}`
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View on {selectedAsset.type === 'crypto' ? 'CoinMarketCap' : 'Yahoo Finance'}
                    </Button>
                  </a>
                </div>
              </div>
            ) : (
              <div className="bg-zinc-900 rounded-xl p-8 text-center">
                <DollarSign className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                <p className="text-zinc-400">Select an asset to view details</p>
              </div>
            )}
          </div>
        </div>

        <div className="mt-12 p-6 bg-zinc-900 rounded-xl">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-amber-500/20 rounded-lg">
              <AlertTriangle className="h-6 w-6 text-amber-400" />
            </div>
            <div>
              <h3 className="text-white font-medium mb-2">Investment Disclaimer</h3>
              <p className="text-zinc-400 text-sm leading-relaxed">
                These recommendations are based on historical data and market analysis. 
                Past performance does not guarantee future results. All investments carry risk, 
                and you should conduct your own research before making investment decisions. 
                Consider consulting with a financial advisor for personalized advice.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
