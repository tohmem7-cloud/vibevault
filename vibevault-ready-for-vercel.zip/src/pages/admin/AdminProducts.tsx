import { useState } from 'react';
import { 
  Plus, 
  Search, 
  MoreVertical, 
  Edit, 
  Trash2, 
  Eye,
  ArrowLeft,
  Upload,
  Pencil,
  X
} from 'lucide-react';
import { products as initialProducts, categories } from '@/data/products';
import { formatPrice } from '@/utils/helpers';
import { useNavigation } from '@/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import type { Product } from '@/types';

export default function AdminProducts() {
  const { navigate } = useNavigation();
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProducts, setSelectedProducts] = useState<string[]>([]);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedProducts(filteredProducts.map(p => p.id));
    } else {
      setSelectedProducts([]);
    }
  };

  const handleSelectProduct = (productId: string, checked: boolean) => {
    if (checked) {
      setSelectedProducts([...selectedProducts, productId]);
    } else {
      setSelectedProducts(selectedProducts.filter(id => id !== productId));
    }
  };

  const handleDelete = (productId: string) => {
    setProducts(products.filter(p => p.id !== productId));
    toast.success('Product deleted successfully');
  };

  const handleBulkDelete = () => {
    setProducts(products.filter(p => !selectedProducts.includes(p.id)));
    toast.success(`${selectedProducts.length} products deleted`);
    setSelectedProducts([]);
  };

  const handleEdit = (product: Product) => {
    setEditingProduct({ ...product });
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = (updatedProduct: Product) => {
    setProducts(products.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    setIsEditDialogOpen(false);
    setEditingProduct(null);
    toast.success('Product updated successfully');
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts([...products, newProduct]);
    setIsAddDialogOpen(false);
    toast.success('Product added successfully');
  };

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button onClick={() => navigate('admin')} variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl text-white font-medium">Products</h1>
              <p className="text-zinc-400">Manage your product inventory</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-purple-500 to-pink-500">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-zinc-900 border-zinc-800 max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-white">Add New Product</DialogTitle>
                </DialogHeader>
                <AddProductForm onClose={() => setIsAddDialogOpen(false)} onAdd={handleAddProduct} />
              </DialogContent>
            </Dialog>
            <Button variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
              <Upload className="h-4 w-4 mr-2" />
              Import CSV
            </Button>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products..."
              className="bg-zinc-900 border-zinc-700 text-white pl-10"
            />
          </div>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-zinc-900 border border-zinc-700 text-white px-4 py-2 rounded-lg"
          >
            <option value="all">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>
        </div>

        {selectedProducts.length > 0 && (
          <div className="flex items-center gap-4 mb-4 p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
            <span className="text-white">{selectedProducts.length} selected</span>
            <Button
              onClick={handleBulkDelete}
              variant="destructive"
              size="sm"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Delete Selected
            </Button>
          </div>
        )}

        <div className="bg-zinc-900 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-zinc-800">
                  <th className="text-left py-4 px-4">
                    <Checkbox
                      checked={selectedProducts.length === filteredProducts.length && filteredProducts.length > 0}
                      onCheckedChange={handleSelectAll}
                      className="border-zinc-600 data-[state=checked]:bg-purple-500"
                    />
                  </th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Product</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Category</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Price</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Stock</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Status</th>
                  <th className="text-right text-zinc-400 text-sm font-medium py-4 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((product) => (
                  <tr
                    key={product.id}
                    className="border-b border-zinc-800/50 hover:bg-zinc-800/50 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <Checkbox
                        checked={selectedProducts.includes(product.id)}
                        onCheckedChange={(checked) => handleSelectProduct(product.id, checked as boolean)}
                        className="border-zinc-600 data-[state=checked]:bg-purple-500"
                      />
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-12 h-12 object-cover rounded-lg"
                        />
                        <div>
                          <p className="text-white font-medium">{product.name}</p>
                          <p className="text-zinc-400 text-sm">{product.brand}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-zinc-300 capitalize">{product.category}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-white">{formatPrice(product.price)}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className={`${product.stockCount < 10 ? 'text-red-400' : 'text-zinc-300'}`}>
                        {product.stockCount}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex gap-2 flex-wrap">
                        {product.isPreorder && (
                          <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs rounded">
                            Preorder
                          </span>
                        )}
                        {product.isNew && (
                          <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs rounded">
                            New
                          </span>
                        )}
                        {product.isBestseller && (
                          <span className="px-2 py-1 bg-amber-500/20 text-amber-400 text-xs rounded">
                            Bestseller
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {/* Pencil Edit Button */}
                        <Button
                          onClick={() => handleEdit(product)}
                          variant="ghost"
                          size="sm"
                          className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/10"
                          title="Edit Product"
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="text-zinc-400 hover:text-white">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent className="bg-zinc-800 border-zinc-700">
                            <DropdownMenuItem 
                              onClick={() => navigate(`product-${product.id}`)}
                              className="text-white hover:bg-zinc-700 cursor-pointer"
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              View
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleEdit(product)}
                              className="text-white hover:bg-zinc-700 cursor-pointer"
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem 
                              onClick={() => handleDelete(product.id)}
                              className="text-red-400 hover:bg-zinc-700 cursor-pointer"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex items-center justify-between mt-6">
          <p className="text-zinc-400 text-sm">
            Showing {filteredProducts.length} of {products.length} products
          </p>
          <div className="flex gap-2">
            <Button variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800" disabled>
              Previous
            </Button>
            <Button variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800" disabled>
              Next
            </Button>
          </div>
        </div>
      </div>

      {/* Edit Product Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-zinc-900 border-zinc-800 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2">
              <Pencil className="h-5 w-5 text-purple-400" />
              Edit Product
            </DialogTitle>
          </DialogHeader>
          {editingProduct && (
            <EditProductForm 
              product={editingProduct} 
              onClose={() => setIsEditDialogOpen(false)} 
              onSave={handleSaveEdit} 
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function AddProductForm({ onClose, onAdd }: { onClose: () => void; onAdd: (product: Product) => void }) {
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    price: '',
    category: 'hoodies',
    stock: '',
    description: '',
    image: '',
    isPreorder: false,
    isNew: false,
    isBestseller: false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newProduct: Product = {
      id: `product-${Date.now()}`,
      name: formData.name,
      brand: formData.brand,
      price: parseFloat(formData.price),
      category: formData.category as 'hoodies' | 'pants' | 'tracksuits' | 'colognes',
      image: formData.image || 'https://images.stockx.com/images/placeholder.jpg',
      images: [formData.image || 'https://images.stockx.com/images/placeholder.jpg'],
      sizes: ['S', 'M', 'L', 'XL'],
      colors: [{ name: 'Default', hex: '#000000' }],
      description: formData.description,
      details: [],
      inStock: true,
      stockCount: parseInt(formData.stock),
      isPreorder: formData.isPreorder,
      isNew: formData.isNew,
      isBestseller: formData.isBestseller,
      rating: 0,
      reviewCount: 0,
    };
    onAdd(newProduct);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-zinc-300">Product Name</Label>
          <Input
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
        <div>
          <Label className="text-zinc-300">Brand</Label>
          <Input
            value={formData.brand}
            onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-zinc-300">Price (CAD)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
        <div>
          <Label className="text-zinc-300">Stock</Label>
          <Input
            type="number"
            value={formData.stock}
            onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
      </div>
      
      <div>
        <Label className="text-zinc-300">Category</Label>
        <select
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value as 'hoodies' | 'pants' | 'tracksuits' | 'colognes' })}
          className="w-full bg-zinc-800 border border-zinc-700 text-white px-3 py-2 rounded-lg"
        >
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>
      </div>
      
      <div>
        <Label className="text-zinc-300">Description</Label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          rows={3}
          className="w-full bg-zinc-800 border border-zinc-700 text-white px-3 py-2 rounded-lg resize-none"
        />
      </div>

      <div>
        <Label className="text-zinc-300">Image URL</Label>
        <Input
          type="url"
          value={formData.image}
          onChange={(e) => setFormData({ ...formData, image: e.target.value })}
          placeholder="https://images.stockx.com/images/..."
          className="bg-zinc-800 border-zinc-700 text-white"
        />
        <p className="text-zinc-500 text-xs mt-1">Enter a StockX or trusted image URL</p>
      </div>

      <div className="flex gap-4">
        <label className="flex items-center gap-2 cursor-pointer">
          <Checkbox
            checked={formData.isPreorder}
            onCheckedChange={(checked) => setFormData({ ...formData, isPreorder: checked as boolean })}
            className="border-zinc-600 data-[state=checked]:bg-purple-500"
          />
          <span className="text-zinc-300 text-sm">Preorder</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <Checkbox
            checked={formData.isNew}
            onCheckedChange={(checked) => setFormData({ ...formData, isNew: checked as boolean })}
            className="border-zinc-600 data-[state=checked]:bg-purple-500"
          />
          <span className="text-zinc-300 text-sm">New</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <Checkbox
            checked={formData.isBestseller}
            onCheckedChange={(checked) => setFormData({ ...formData, isBestseller: checked as boolean })}
            className="border-zinc-600 data-[state=checked]:bg-purple-500"
          />
          <span className="text-zinc-300 text-sm">Bestseller</span>
        </label>
      </div>
      
      <div className="flex gap-4 pt-4">
        <Button
          type="button"
          onClick={onClose}
          variant="outline"
          className="flex-1 border-zinc-700 text-white hover:bg-zinc-800"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500"
        >
          Add Product
        </Button>
      </div>
    </form>
  );
}

function EditProductForm({ product, onClose, onSave }: { product: Product; onClose: () => void; onSave: (product: Product) => void }) {
  const [formData, setFormData] = useState({
    name: product.name,
    brand: product.brand,
    price: product.price.toString(),
    category: product.category,
    stock: product.stockCount.toString(),
    description: product.description,
    image: product.image,
    isPreorder: product.isPreorder || false,
    isNew: product.isNew || false,
    isBestseller: product.isBestseller || false,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updatedProduct: Product = {
      ...product,
      name: formData.name,
      brand: formData.brand,
      price: parseFloat(formData.price),
      category: formData.category,
      image: formData.image,
      images: [formData.image, ...(product.images?.slice(1) || [])],
      description: formData.description,
      stockCount: parseInt(formData.stock),
      isPreorder: formData.isPreorder,
      isNew: formData.isNew,
      isBestseller: formData.isBestseller,
    };
    onSave(updatedProduct);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Product Preview */}
      <div className="flex items-center gap-4 p-4 bg-zinc-800/50 rounded-lg mb-4">
        <img
          src={formData.image}
          alt={formData.name}
          className="w-16 h-16 object-cover rounded-lg"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.stockx.com/images/placeholder.jpg';
          }}
        />
        <div>
          <p className="text-white font-medium">{formData.name || 'Product Name'}</p>
          <p className="text-zinc-400 text-sm">{formData.brand || 'Brand'}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-zinc-300">Product Name</Label>
          <Input
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
        <div>
          <Label className="text-zinc-300">Brand</Label>
          <Input
            value={formData.brand}
            onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-zinc-300">Price (CAD)</Label>
          <Input
            type="number"
            step="0.01"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
        <div>
          <Label className="text-zinc-300">Stock</Label>
          <Input
            type="number"
            value={formData.stock}
            onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
            className="bg-zinc-800 border-zinc-700 text-white"
            required
          />
        </div>
      </div>
      
      <div>
        <Label className="text-zinc-300">Category</Label>
        <select
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value as 'hoodies' | 'pants' | 'tracksuits' | 'colognes' })}
          className="w-full bg-zinc-800 border border-zinc-700 text-white px-3 py-2 rounded-lg"
        >
          {categories.map(cat => (
            <option key={cat.id} value={cat.id}>{cat.name}</option>
          ))}
        </select>
      </div>
      
      <div>
        <Label className="text-zinc-300">Description</Label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          rows={3}
          className="w-full bg-zinc-800 border border-zinc-700 text-white px-3 py-2 rounded-lg resize-none"
        />
      </div>

      <div>
        <Label className="text-zinc-300">Image URL</Label>
        <Input
          type="url"
          value={formData.image}
          onChange={(e) => setFormData({ ...formData, image: e.target.value })}
          placeholder="https://images.stockx.com/images/..."
          className="bg-zinc-800 border-zinc-700 text-white"
        />
        <p className="text-zinc-500 text-xs mt-1">Enter a StockX or trusted image URL</p>
      </div>

      <div className="flex gap-4">
        <label className="flex items-center gap-2 cursor-pointer">
          <Checkbox
            checked={formData.isPreorder}
            onCheckedChange={(checked) => setFormData({ ...formData, isPreorder: checked as boolean })}
            className="border-zinc-600 data-[state=checked]:bg-purple-500"
          />
          <span className="text-zinc-300 text-sm">Preorder</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <Checkbox
            checked={formData.isNew}
            onCheckedChange={(checked) => setFormData({ ...formData, isNew: checked as boolean })}
            className="border-zinc-600 data-[state=checked]:bg-purple-500"
          />
          <span className="text-zinc-300 text-sm">New</span>
        </label>
        <label className="flex items-center gap-2 cursor-pointer">
          <Checkbox
            checked={formData.isBestseller}
            onCheckedChange={(checked) => setFormData({ ...formData, isBestseller: checked as boolean })}
            className="border-zinc-600 data-[state=checked]:bg-purple-500"
          />
          <span className="text-zinc-300 text-sm">Bestseller</span>
        </label>
      </div>
      
      <div className="flex gap-4 pt-4">
        <Button
          type="button"
          onClick={onClose}
          variant="outline"
          className="flex-1 border-zinc-700 text-white hover:bg-zinc-800"
        >
          <X className="h-4 w-4 mr-2" />
          Cancel
        </Button>
        <Button
          type="submit"
          className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500"
        >
          <Pencil className="h-4 w-4 mr-2" />
          Save Changes
        </Button>
      </div>
    </form>
  );
}
