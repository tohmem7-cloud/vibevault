import { useState } from 'react';
import { 
  ArrowLeft, 
  Search, 
  Package, 
  Truck, 
  CheckCircle,
  Clock,
  XCircle,
  Eye,
  Download
} from 'lucide-react';
import { useNavigation } from '@/store';
import { formatPrice } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

const mockOrders = [
  {
    id: 'VV-ABC123',
    customer: 'john.doe@email.com',
    items: [
      { name: 'Off-White Diagonal Arrow Hoodie', quantity: 1, price: 110 },
      { name: 'Amiri MX1 Jeans', quantity: 1, price: 90 }
    ],
    total: 200,
    status: 'pending',
    createdAt: '2024-02-10',
    shippingAddress: {
      firstName: 'John',
      lastName: 'Doe',
      address: '123 Main St',
      city: 'Toronto',
      province: 'ON',
      postalCode: 'M5V 3A8'
    }
  },
  {
    id: 'VV-DEF456',
    customer: 'jane.smith@email.com',
    items: [
      { name: 'Dior Sauvage EDP', quantity: 1, price: 135 }
    ],
    total: 135,
    status: 'processing',
    createdAt: '2024-02-09',
    shippingAddress: {
      firstName: 'Jane',
      lastName: 'Smith',
      address: '456 Queen St',
      city: 'Vancouver',
      province: 'BC',
      postalCode: 'V6B 3L4'
    }
  },
  {
    id: 'VV-GHI789',
    customer: 'mike.wilson@email.com',
    items: [
      { name: 'Nike Tech Fleece Tracksuit', quantity: 1, price: 240 },
      { name: 'Supreme Box Logo Hoodie', quantity: 1, price: 105 }
    ],
    total: 345,
    status: 'shipped',
    trackingNumber: '1Z999AA10123456784',
    createdAt: '2024-02-08',
    shippingAddress: {
      firstName: 'Mike',
      lastName: 'Wilson',
      address: '789 King St',
      city: 'Montreal',
      province: 'QC',
      postalCode: 'H3A 0G4'
    }
  },
  {
    id: 'VV-JKL012',
    customer: 'sarah.brown@email.com',
    items: [
      { name: 'Creed Aventus EDP', quantity: 1, price: 185 }
    ],
    total: 185,
    status: 'delivered',
    createdAt: '2024-02-05',
    shippingAddress: {
      firstName: 'Sarah',
      lastName: 'Brown',
      address: '321 Yonge St',
      city: 'Toronto',
      province: 'ON',
      postalCode: 'M5B 2L7'
    }
  },
];

export default function AdminOrders() {
  const { navigate } = useNavigation();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredOrders = mockOrders.filter(order => {
    const matchesSearch = 
      order.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-amber-400" />;
      case 'processing':
        return <Package className="h-4 w-4 text-blue-400" />;
      case 'shipped':
        return <Truck className="h-4 w-4 text-purple-400" />;
      case 'delivered':
        return <CheckCircle className="h-4 w-4 text-green-400" />;
      case 'cancelled':
        return <XCircle className="h-4 w-4 text-red-400" />;
      default:
        return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-amber-500/20 text-amber-400';
      case 'processing':
        return 'bg-blue-500/20 text-blue-400';
      case 'shipped':
        return 'bg-purple-500/20 text-purple-400';
      case 'delivered':
        return 'bg-green-500/20 text-green-400';
      case 'cancelled':
        return 'bg-red-500/20 text-red-400';
      default:
        return 'bg-zinc-500/20 text-zinc-400';
    }
  };

  const handleUpdateStatus = (orderId: string, newStatus: string) => {
    toast.success(`Order ${orderId} status updated to ${newStatus}`);
  };

  const handleExport = () => {
    toast.success('Orders exported to CSV');
  };

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div className="flex items-center gap-4">
            <Button onClick={() => navigate('admin')} variant="outline" className="border-zinc-700 text-white hover:bg-zinc-800">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl text-white font-medium">Orders</h1>
              <p className="text-zinc-400">Manage customer orders</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            className="border-zinc-700 text-white hover:bg-zinc-800"
            onClick={handleExport}
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          {[
            { label: 'Total Orders', value: mockOrders.length, color: 'text-white' },
            { label: 'Pending', value: mockOrders.filter(o => o.status === 'pending').length, color: 'text-amber-400' },
            { label: 'Processing', value: mockOrders.filter(o => o.status === 'processing').length, color: 'text-blue-400' },
            { label: 'Shipped', value: mockOrders.filter(o => o.status === 'shipped').length, color: 'text-purple-400' },
            { label: 'Delivered', value: mockOrders.filter(o => o.status === 'delivered').length, color: 'text-green-400' },
          ].map((stat) => (
            <div key={stat.label} className="bg-zinc-900 rounded-xl p-4">
              <p className="text-zinc-400 text-sm">{stat.label}</p>
              <p className={`text-2xl font-medium ${stat.color}`}>{stat.value}</p>
            </div>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search orders..."
              className="bg-zinc-900 border-zinc-700 text-white pl-10"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-zinc-900 border border-zinc-700 text-white px-4 py-2 rounded-lg"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        <div className="bg-zinc-900 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-zinc-800">
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Order ID</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Customer</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Items</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Total</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Status</th>
                  <th className="text-left text-zinc-400 text-sm font-medium py-4 px-4">Date</th>
                  <th className="text-right text-zinc-400 text-sm font-medium py-4 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.map((order) => (
                  <tr
                    key={order.id}
                    className="border-b border-zinc-800/50 hover:bg-zinc-800/50 transition-colors"
                  >
                    <td className="py-4 px-4">
                      <span className="text-white font-medium">{order.id}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-zinc-300">{order.customer}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-zinc-300">{order.items.length} items</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-white">{formatPrice(order.total)}</span>
                    </td>
                    <td className="py-4 px-4">
                      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <span className="text-zinc-400">{order.createdAt}</span>
                    </td>
                    <td className="py-4 px-4 text-right">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="ghost" className="text-zinc-400 hover:text-white">
                            <Eye className="h-4 w-4 mr-2" />
                            View
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-zinc-900 border-zinc-800 max-w-2xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle className="text-white">Order Details - {order.id}</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-6">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="bg-zinc-800 rounded-lg p-4">
                                <p className="text-zinc-400 text-sm">Customer</p>
                                <p className="text-white">{order.customer}</p>
                              </div>
                              <div className="bg-zinc-800 rounded-lg p-4">
                                <p className="text-zinc-400 text-sm">Order Date</p>
                                <p className="text-white">{order.createdAt}</p>
                              </div>
                            </div>

                            <div className="bg-zinc-800 rounded-lg p-4">
                              <p className="text-zinc-400 text-sm mb-2">Status</p>
                              <div className="flex items-center gap-2">
                                <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm ${getStatusColor(order.status)}`}>
                                  {getStatusIcon(order.status)}
                                  {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                </span>
                                {order.trackingNumber && (
                                  <span className="text-zinc-400 text-sm">
                                    Tracking: {order.trackingNumber}
                                  </span>
                                )}
                              </div>
                            </div>

                            <div>
                              <p className="text-zinc-400 text-sm mb-2">Items</p>
                              <div className="space-y-2">
                                {order.items.map((item, index) => (
                                  <div key={index} className="flex justify-between bg-zinc-800 rounded-lg p-4">
                                    <div>
                                      <p className="text-white">{item.name}</p>
                                      <p className="text-zinc-400 text-sm">Qty: {item.quantity}</p>
                                    </div>
                                    <p className="text-white">{formatPrice(item.price)}</p>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="flex justify-between items-center pt-4 border-t border-zinc-800">
                              <p className="text-zinc-400">Total</p>
                              <p className="text-white text-xl font-medium">{formatPrice(order.total)}</p>
                            </div>

                            <div className="bg-zinc-800 rounded-lg p-4">
                              <p className="text-zinc-400 text-sm mb-2">Shipping Address</p>
                              <p className="text-white">
                                {order.shippingAddress.firstName} {order.shippingAddress.lastName}
                              </p>
                              <p className="text-zinc-300">
                                {order.shippingAddress.address}
                              </p>
                              <p className="text-zinc-300">
                                {order.shippingAddress.city}, {order.shippingAddress.province} {order.shippingAddress.postalCode}
                              </p>
                            </div>

                            <div className="flex gap-2">
                              {order.status === 'pending' && (
                                <Button
                                  onClick={() => handleUpdateStatus(order.id, 'processing')}
                                  className="flex-1 bg-blue-500 hover:bg-blue-600"
                                >
                                  Mark as Processing
                                </Button>
                              )}
                              {order.status === 'processing' && (
                                <Button
                                  onClick={() => handleUpdateStatus(order.id, 'shipped')}
                                  className="flex-1 bg-purple-500 hover:bg-purple-600"
                                >
                                  Mark as Shipped
                                </Button>
                              )}
                              {order.status === 'shipped' && (
                                <Button
                                  onClick={() => handleUpdateStatus(order.id, 'delivered')}
                                  className="flex-1 bg-green-500 hover:bg-green-600"
                                >
                                  Mark as Delivered
                                </Button>
                              )}
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-8 p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
          <div className="flex items-center gap-2 text-purple-400 mb-2">
            <Clock className="h-5 w-5" />
            <span className="font-medium">Preorder Information</span>
          </div>
          <p className="text-zinc-400 text-sm">
            All preorders will ship on February 23rd due to Chinese New Year. 
            Customers have been notified of the shipping date.
          </p>
        </div>
      </div>
    </div>
  );
}
