import { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, User, Shield } from 'lucide-react';
import { useAuth, useNavigation } from '@/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';

export default function Login() {
  const { navigate } = useNavigation();
  const { login, setAdmin } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showSecurityQuestion, setShowSecurityQuestion] = useState(false);
  const [securityAnswer, setSecurityAnswer] = useState('');
  
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    confirmPassword: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (formData.email === 'tohmem7@gmail.com' && formData.password === 'mohamad7') {
      setShowSecurityQuestion(true);
      setIsLoading(false);
      return;
    }

    if (isLogin) {
      const result = login(formData.email, formData.password);
      if (result.success) {
        toast.success('Logged in successfully!');
        navigate('account');
      } else {
        toast.error('Invalid credentials');
      }
    } else {
      toast.success('Account created successfully!');
      navigate('account');
    }
    
    setIsLoading(false);
  };

  const handleSecuritySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (securityAnswer.toLowerCase() === 'rex') {
      setAdmin(true);
      toast.success('Admin access granted!');
      navigate('admin');
    } else {
      toast.error('Incorrect security answer');
    }
  };

  if (showSecurityQuestion) {
    return (
      <div className="min-h-screen bg-black pt-24 pb-20 flex items-center justify-center">
        <div className="w-full max-w-md px-4 animate-slide-up">
          <div className="bg-zinc-900 rounded-xl p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-purple-400" />
              </div>
              <h1 className="text-2xl text-white font-medium">Security Check</h1>
              <p className="text-zinc-400 mt-2">Please answer the security question to continue</p>
            </div>

            <form onSubmit={handleSecuritySubmit} className="space-y-6">
              <div>
                <Label className="text-zinc-300 text-lg">What is your favorite animal?</Label>
                <Input
                  type="text"
                  value={securityAnswer}
                  onChange={(e) => setSecurityAnswer(e.target.value)}
                  placeholder="Enter your answer"
                  className="bg-zinc-800 border-zinc-700 text-white mt-2"
                  autoFocus
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 py-6"
              >
                Verify
              </Button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black pt-24 pb-20 flex items-center justify-center">
      <div className="w-full max-w-md px-4 animate-slide-up">
        <div className="bg-zinc-900 rounded-xl p-8">
          <div className="text-center mb-8">
            <h1 className="font-display text-4xl bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent">
              VIBEVAULT
            </h1>
            <p className="text-zinc-400 mt-2">
              {isLogin ? 'Welcome back! Sign in to continue' : 'Create an account to get started'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-zinc-300">First Name</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                    <Input
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      className="bg-zinc-800 border-zinc-700 text-white pl-10"
                      placeholder="John"
                      required={!isLogin}
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-zinc-300">Last Name</Label>
                  <Input
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="bg-zinc-800 border-zinc-700 text-white"
                    placeholder="Doe"
                    required={!isLogin}
                  />
                </div>
              </div>
            )}

            <div>
              <Label className="text-zinc-300">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-zinc-800 border-zinc-700 text-white pl-10"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <Label className="text-zinc-300">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                <Input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="bg-zinc-800 border-zinc-700 text-white pl-10 pr-10"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {!isLogin && (
              <div>
                <Label className="text-zinc-300">Confirm Password</Label>
                <Input
                  type="password"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="bg-zinc-800 border-zinc-700 text-white"
                  placeholder="••••••••"
                  required={!isLogin}
                />
              </div>
            )}

            {isLogin && (
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 cursor-pointer">
                  <Checkbox className="border-zinc-600 data-[state=checked]:bg-purple-500" />
                  <span className="text-zinc-400 text-sm">Remember me</span>
                </label>
                <button className="text-purple-400 text-sm hover:text-purple-300">
                  Forgot password?
                </button>
              </div>
            )}

            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 py-6"
            >
              {isLoading ? 'Please wait...' : isLogin ? 'Sign In' : 'Create Account'}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-zinc-400">
              {isLogin ? "Don't have an account?" : 'Already have an account?'}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="text-purple-400 hover:text-purple-300 ml-1"
              >
                {isLogin ? 'Sign up' : 'Sign in'}
              </button>
            </p>
          </div>

          <div className="mt-8 pt-6 border-t border-zinc-800 text-center">
            <p className="text-zinc-500 text-xs">
              Admin login: tohmem7@gmail.com / mohamad7
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
