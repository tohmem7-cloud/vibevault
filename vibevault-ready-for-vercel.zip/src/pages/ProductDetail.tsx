import { useState } from 'react';
import { Star, Heart, Share2, Truck, Shield, Clock, Check, Plus, Minus } from 'lucide-react';
import { products } from '@/data/products';
import { useCart, useWishlist, useNavigation } from '@/store';
import { formatPrice } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';

export default function ProductDetail() {
  const product = products.find(p => p.id === state.selectedProductId);
  if (!product) return null; // Show first product as example
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const { navigate } = useNavigation();
  
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedMl, setSelectedMl] = useState<number | undefined>();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    if (!selectedSize && product.sizes.length > 0 && product.sizes[0] !== 'One Size') {
      toast.error('Please select a size');
      return;
    }
    if (product.mlOptions && !selectedMl) {
      toast.error('Please select a size (ml)');
      return;
    }

    addToCart({
      product,
      quantity,
      size: selectedSize || product.sizes[0],
      color: selectedColor || product.colors[0]?.name || 'Default',
      ml: selectedMl,
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: product.name,
          text: `Check out ${product.name} on VibeVault!`,
          url: window.location.href,
        });
      } catch {
        // User cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Link copied to clipboard!');
    }
  };

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-zinc-400 mb-8">
          <button onClick={() => navigate('home')} className="hover:text-white transition-colors">Home</button>
          <span>/</span>
          <button onClick={() => navigate('shop')} className="hover:text-white transition-colors">Shop</button>
          <span>/</span>
          <button onClick={() => navigate('shop')} className="hover:text-white transition-colors capitalize">
            {product.category}
          </button>
          <span>/</span>
          <span className="text-white">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Images */}
          <div>
            <div className="relative bg-zinc-900 rounded-xl overflow-hidden">
              {product.isPreorder && (
                <div className="absolute top-4 left-4 z-10 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-sm font-medium rounded-full">
                  Preorder - Ships Feb 23
                </div>
              )}
              <img
                src={product.images[selectedImage] || product.image}
                alt={product.name}
                className="w-full aspect-square object-cover"
              />
            </div>
            
            {product.images.length > 1 && (
              <div className="flex gap-2 mt-4">
                {product.images.map((img, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors ${
                      selectedImage === index ? 'border-purple-500' : 'border-transparent'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-zinc-400">{product.brand}</p>
                <h1 className="text-3xl sm:text-4xl text-white font-medium mt-1">{product.name}</h1>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleWishlist(product.id)}
                  className={`p-3 rounded-full transition-colors ${
                    isInWishlist(product.id)
                      ? 'bg-red-500/20 text-red-400'
                      : 'bg-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Heart className={`h-5 w-5 ${isInWishlist(product.id) ? 'fill-current' : ''}`} />
                </button>
                <button
                  onClick={handleShare}
                  className="p-3 bg-zinc-800 rounded-full text-zinc-400 hover:text-white transition-colors"
                >
                  <Share2 className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4 mt-4">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating)
                        ? 'text-amber-400 fill-amber-400'
                        : 'text-zinc-600'
                    }`}
                  />
                ))}
              </div>
              <span className="text-white">{product.rating}</span>
              <span className="text-zinc-500">({product.reviewCount} reviews)</span>
            </div>

            <div className="mt-6">
              <span className="text-4xl text-white font-medium">{formatPrice(product.price)}</span>
              <span className="text-zinc-500 ml-2">CAD</span>
            </div>

            {product.isPreorder && (
              <div className="mt-4 p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <div className="flex items-center gap-2 text-purple-400">
                  <Clock className="h-5 w-5" />
                  <span className="font-medium">Preorder Item</span>
                </div>
                <p className="text-zinc-400 text-sm mt-1">
                  Due to Chinese New Year, this item will ship on February 23rd with FREE shipping.
                </p>
              </div>
            )}

            {product.stockCount < 10 && (
              <p className="mt-4 text-red-400 text-sm">
                Only {product.stockCount} left in stock - order soon!
              </p>
            )}

            <div className="mt-8 space-y-6">
              {product.colors.length > 1 && (
                <div>
                  <label className="text-white font-medium mb-3 block">
                    Color: <span className="text-zinc-400">{selectedColor || product.colors[0].name}</span>
                  </label>
                  <div className="flex gap-3">
                    {product.colors.map((color) => (
                      <button
                        key={color.name}
                        onClick={() => setSelectedColor(color.name)}
                        className={`w-10 h-10 rounded-full border-2 transition-all ${
                          selectedColor === color.name
                            ? 'border-purple-500 scale-110'
                            : 'border-zinc-600 hover:border-zinc-500'
                        }`}
                        style={{ backgroundColor: color.hex }}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              )}

              {product.sizes.length > 0 && product.sizes[0] !== 'One Size' && (
                <div>
                  <label className="text-white font-medium mb-3 block">
                    Size: <span className="text-zinc-400">{selectedSize || 'Select'}</span>
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`px-4 py-2 rounded-lg border transition-all ${
                          selectedSize === size
                            ? 'border-purple-500 bg-purple-500/20 text-white'
                            : 'border-zinc-700 text-zinc-300 hover:border-zinc-500'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {product.mlOptions && (
                <div>
                  <label className="text-white font-medium mb-3 block">
                    Size: <span className="text-zinc-400">{selectedMl ? `${selectedMl}ml` : 'Select'}</span>
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.mlOptions.map((ml) => (
                      <button
                        key={ml}
                        onClick={() => setSelectedMl(ml)}
                        className={`px-4 py-2 rounded-lg border transition-all ${
                          selectedMl === ml
                            ? 'border-purple-500 bg-purple-500/20 text-white'
                            : 'border-zinc-700 text-zinc-300 hover:border-zinc-500'
                        }`}
                      >
                        {ml}ml
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <label className="text-white font-medium mb-3 block">Quantity</label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-2 bg-zinc-800 rounded-lg text-white hover:bg-zinc-700 transition-colors"
                  >
                    <Minus className="h-5 w-5" />
                  </button>
                  <span className="text-white text-xl font-medium w-12 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-2 bg-zinc-800 rounded-lg text-white hover:bg-zinc-700 transition-colors"
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-8 flex gap-4">
              <Button
                onClick={handleAddToCart}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-6 text-lg"
              >
                Add to Cart
              </Button>
              <Button
                onClick={() => { handleAddToCart(); navigate('checkout'); }}
                variant="outline"
                className="flex-1 border-zinc-700 text-white hover:bg-zinc-800 py-6 text-lg"
              >
                Buy Now
              </Button>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-zinc-900 rounded-lg">
                <Truck className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                <p className="text-zinc-400 text-xs">Free Shipping</p>
              </div>
              <div className="text-center p-4 bg-zinc-900 rounded-lg">
                <Shield className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                <p className="text-zinc-400 text-xs">Authentic</p>
              </div>
              <div className="text-center p-4 bg-zinc-900 rounded-lg">
                <Clock className="h-6 w-6 text-purple-400 mx-auto mb-2" />
                <p className="text-zinc-400 text-xs">Fast Delivery</p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-16">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="bg-zinc-900 border-b border-zinc-800 w-full justify-start rounded-none">
              <TabsTrigger value="description" className="data-[state=active]:bg-zinc-800 text-white">
                Description
              </TabsTrigger>
              <TabsTrigger value="details" className="data-[state=active]:bg-zinc-800 text-white">
                Details
              </TabsTrigger>
              {product.scentNotes && (
                <TabsTrigger value="scent" className="data-[state=active]:bg-zinc-800 text-white">
                  Scent Notes
                </TabsTrigger>
              )}
              <TabsTrigger value="shipping" className="data-[state=active]:bg-zinc-800 text-white">
                Shipping
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <p className="text-zinc-300 leading-relaxed">{product.description}</p>
            </TabsContent>
            
            <TabsContent value="details" className="mt-6">
              <ul className="space-y-2">
                {product.details.map((detail, index) => (
                  <li key={index} className="flex items-center gap-2 text-zinc-300">
                    <Check className="h-4 w-4 text-purple-400" />
                    {detail}
                  </li>
                ))}
              </ul>
            </TabsContent>
            
            {product.scentNotes && (
              <TabsContent value="scent" className="mt-6">
                <div className="flex flex-wrap gap-3">
                  {product.scentNotes.map((note, index) => (
                    <span
                      key={index}
                      className="px-4 py-2 bg-zinc-900 text-zinc-300 rounded-full"
                    >
                      {note}
                    </span>
                  ))}
                </div>
              </TabsContent>
            )}
            
            <TabsContent value="shipping" className="mt-6">
              <div className="space-y-4 text-zinc-300">
                <p>
                  <strong className="text-white">Preorder Shipping:</strong> All preorders will ship on February 23rd due to Chinese New Year. FREE shipping on all preorders.
                </p>
                <p>
                  <strong className="text-white">Regular Shipping:</strong> After February 23rd, standard shipping rates apply ($3 CAD per order).
                </p>
                <p>
                  <strong className="text-white">Delivery Time:</strong> 14 business days from ship date.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {relatedProducts.length > 0 && (
          <div className="mt-20">
            <h2 className="font-display text-3xl text-white mb-8">You May Also Like</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((product) => (
                <button
                  key={product.id}
                  onClick={() => navigate('product')}
                  className="group text-left"
                >
                  <div className="aspect-[3/4] bg-zinc-900 rounded-xl overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>
                  <div className="mt-4">
                    <p className="text-zinc-500 text-sm">{product.brand}</p>
                    <h3 className="text-white font-medium group-hover:text-purple-400 transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                    <p className="text-white mt-1">{formatPrice(product.price)} CAD</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
