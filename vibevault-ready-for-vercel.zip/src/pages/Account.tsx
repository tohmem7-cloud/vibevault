import { useState } from 'react';
import { Package, Heart, MapPin, User, LogOut, Settings } from 'lucide-react';
import { useAuth, useWishlist, useStore, useNavigation } from '@/store';
import { products } from '@/data/products';
import { formatPrice } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function Account() {
  const { navigate } = useNavigation();
  const { user, logout } = useAuth();
  const { wishlist, toggleWishlist } = useWishlist();
  const { state } = useStore();
  
  const [activeTab, setActiveTab] = useState('orders');

  if (!user && !state.isAdmin) {
    return (
      <div className="min-h-screen bg-black pt-24 pb-20 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl text-white mb-4">Please sign in</h1>
          <Button 
            onClick={() => navigate('login')}
            className="bg-gradient-to-r from-purple-500 to-pink-500"
          >
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('home');
  };

  const wishlistProducts = products.filter(p => wishlist.includes(p.id));

  return (
    <div className="min-h-screen bg-black pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl text-white font-medium">My Account</h1>
            <p className="text-zinc-400">Welcome back, {user?.firstName || 'Admin'}</p>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="border-zinc-700 text-white hover:bg-zinc-800"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-zinc-900 rounded-xl p-4">
              <nav className="space-y-1">
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === 'orders' ? 'bg-purple-500/20 text-purple-400' : 'text-zinc-400 hover:bg-zinc-800'
                  }`}
                >
                  <Package className="h-5 w-5" />
                  <span>Orders</span>
                </button>
                <button
                  onClick={() => setActiveTab('wishlist')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === 'wishlist' ? 'bg-purple-500/20 text-purple-400' : 'text-zinc-400 hover:bg-zinc-800'
                  }`}
                >
                  <Heart className="h-5 w-5" />
                  <span>Wishlist</span>
                  {wishlist.length > 0 && (
                    <span className="ml-auto bg-purple-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {wishlist.length}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('addresses')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === 'addresses' ? 'bg-purple-500/20 text-purple-400' : 'text-zinc-400 hover:bg-zinc-800'
                  }`}
                >
                  <MapPin className="h-5 w-5" />
                  <span>Addresses</span>
                </button>
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === 'profile' ? 'bg-purple-500/20 text-purple-400' : 'text-zinc-400 hover:bg-zinc-800'
                  }`}
                >
                  <User className="h-5 w-5" />
                  <span>Profile</span>
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                    activeTab === 'settings' ? 'bg-purple-500/20 text-purple-400' : 'text-zinc-400 hover:bg-zinc-800'
                  }`}
                >
                  <Settings className="h-5 w-5" />
                  <span>Settings</span>
                </button>
              </nav>
            </div>
          </div>

          <div className="lg:col-span-3">
            {activeTab === 'orders' && (
              <div className="animate-fade-in">
                <h2 className="text-xl text-white font-medium mb-6">My Orders</h2>
                {state.orders.length === 0 ? (
                  <div className="bg-zinc-900 rounded-xl p-8 text-center">
                    <Package className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                    <p className="text-zinc-400">No orders yet</p>
                    <Button 
                      onClick={() => navigate('shop')}
                      className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500"
                    >
                      Start Shopping
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {state.orders.map((order) => (
                      <div key={order.id} className="bg-zinc-900 rounded-xl p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <p className="text-white font-medium">{order.id}</p>
                            <p className="text-zinc-400 text-sm">{new Date(order.createdAt).toLocaleDateString()}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-sm ${
                            order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                            order.status === 'shipped' ? 'bg-blue-500/20 text-blue-400' :
                            'bg-amber-500/20 text-amber-400'
                          }`}>
                            {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
                          <p className="text-zinc-400">{order.items.length} items</p>
                          <p className="text-white font-medium">{formatPrice(order.total)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'wishlist' && (
              <div className="animate-fade-in">
                <h2 className="text-xl text-white font-medium mb-6">My Wishlist</h2>
                {wishlistProducts.length === 0 ? (
                  <div className="bg-zinc-900 rounded-xl p-8 text-center">
                    <Heart className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                    <p className="text-zinc-400">Your wishlist is empty</p>
                    <Button 
                      onClick={() => navigate('shop')}
                      className="mt-4 bg-gradient-to-r from-purple-500 to-pink-500"
                    >
                      Browse Products
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                    {wishlistProducts.map((product) => (
                      <div key={product.id} className="bg-zinc-900 rounded-xl overflow-hidden group">
                        <div className="aspect-square relative">
                          <img
                            src={product.image}
                            alt={product.name}
                            className="w-full h-full object-cover"
                          />
                          <button
                            onClick={() => toggleWishlist(product.id)}
                            className="absolute top-2 right-2 p-2 bg-black/50 rounded-full text-red-400 hover:bg-black/70 transition-colors"
                          >
                            <Heart className="h-4 w-4 fill-current" />
                          </button>
                        </div>
                        <div className="p-4">
                          <p className="text-zinc-500 text-sm">{product.brand}</p>
                          <button onClick={() => navigate('product')}>
                            <h3 className="text-white font-medium hover:text-purple-400 transition-colors line-clamp-1 text-left">
                              {product.name}
                            </h3>
                          </button>
                          <p className="text-white mt-1">{formatPrice(product.price)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'addresses' && (
              <div className="animate-fade-in">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl text-white font-medium">Saved Addresses</h2>
                  <Button className="bg-gradient-to-r from-purple-500 to-pink-500">
                    Add New Address
                  </Button>
                </div>
                <div className="bg-zinc-900 rounded-xl p-8 text-center">
                  <MapPin className="h-16 w-16 text-zinc-600 mx-auto mb-4" />
                  <p className="text-zinc-400">No saved addresses</p>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="animate-fade-in">
                <h2 className="text-xl text-white font-medium mb-6">Profile Information</h2>
                <div className="bg-zinc-900 rounded-xl p-6 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-zinc-400 text-sm">First Name</label>
                      <p className="text-white">{user?.firstName || 'N/A'}</p>
                    </div>
                    <div>
                      <label className="text-zinc-400 text-sm">Last Name</label>
                      <p className="text-white">{user?.lastName || 'N/A'}</p>
                    </div>
                  </div>
                  <div>
                    <label className="text-zinc-400 text-sm">Email</label>
                    <p className="text-white">{user?.email || 'N/A'}</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="animate-fade-in">
                <h2 className="text-xl text-white font-medium mb-6">Account Settings</h2>
                <div className="bg-zinc-900 rounded-xl p-6 space-y-4">
                  <div className="flex items-center justify-between py-3 border-b border-zinc-800">
                    <div>
                      <p className="text-white">Email Notifications</p>
                      <p className="text-zinc-400 text-sm">Receive order updates and promotions</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5 accent-purple-500" />
                  </div>
                  <div className="flex items-center justify-between py-3 border-b border-zinc-800">
                    <div>
                      <p className="text-white">Two-Factor Authentication</p>
                      <p className="text-zinc-400 text-sm">Add extra security to your account</p>
                    </div>
                    <input type="checkbox" className="w-5 h-5 accent-purple-500" />
                  </div>
                  <div className="flex items-center justify-between py-3">
                    <div>
                      <p className="text-white text-red-400">Delete Account</p>
                      <p className="text-zinc-400 text-sm">Permanently delete your account</p>
                    </div>
                    <Button variant="destructive" size="sm">
                      Delete
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
