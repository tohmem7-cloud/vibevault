import type { Product } from '@/types';

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-CA', {
    style: 'currency',
    currency: 'CAD'
  }).format(price);
}

export function generateOrderId(): string {
  return 'VV-' + Date.now().toString(36).toUpperCase();
}

export function filterProducts(products: Product[], filters: {
  brands?: string[];
  categories?: string[];
  priceRange?: [number, number];
  sizes?: string[];
  colors?: string[];
  sortBy?: string;
  searchQuery?: string;
}): Product[] {
  let filtered = [...products];

  if (filters.searchQuery) {
    const query = filters.searchQuery.toLowerCase();
    filtered = filtered.filter(
      p =>
        p.name.toLowerCase().includes(query) ||
        p.brand.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query)
    );
  }

  if (filters.brands?.length) {
    filtered = filtered.filter(p => filters.brands!.includes(p.brand));
  }

  if (filters.categories?.length) {
    filtered = filtered.filter(p => filters.categories!.includes(p.category));
  }

  if (filters.priceRange) {
    filtered = filtered.filter(
      p => p.price >= filters.priceRange![0] && p.price <= filters.priceRange![1]
    );
  }

  if (filters.sizes?.length) {
    filtered = filtered.filter(p => p.sizes.some(s => filters.sizes!.includes(s)));
  }

  if (filters.colors?.length) {
    filtered = filtered.filter(p => p.colors.some(c => filters.colors!.includes(c.name)));
  }

  if (filters.sortBy) {
    switch (filters.sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        filtered.sort((a, b) => (a.isNew === b.isNew ? 0 : a.isNew ? -1 : 1));
        break;
      case 'popular':
        filtered.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
    }
  }

  return filtered;
}

export function sendOrderEmail(orderDetails: {
  orderId: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  customerEmail: string;
}): void {
  console.log('Order Email Notification:', {
    to: 'tohmem7@gmail.com',
    subject: `New Order - ${orderDetails.orderId}`,
    body: `
      Order ID: ${orderDetails.orderId}
      Customer: ${orderDetails.customerEmail}
      Items: ${orderDetails.items.map(i => `${i.name} x${i.quantity}`).join(', ')}
      Total: ${formatPrice(orderDetails.total)}
    `
  });
}

export function getTrendingData(): { date: string; value: number }[] {
  const data = [];
  const today = new Date();
  for (let i = 30; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toISOString().split('T')[0],
      value: Math.floor(Math.random() * 50) + 50 + (30 - i) * 2
    });
  }
  return data;
}

export function getTradeRecommendations() {
  return [
    {
      symbol: 'BTC',
      name: 'Bitcoin',
      type: 'crypto' as const,
      potentialReturn: 25,
      risk: 'high' as const,
      reasoning: 'Historical Q1 performance shows 20-30% gains. Halving event approaching.'
    },
    {
      symbol: 'ETH',
      name: 'Ethereum',
      type: 'crypto' as const,
      potentialReturn: 20,
      risk: 'high' as const,
      reasoning: 'Strong DeFi ecosystem growth. ETF approval potential.'
    },
    {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      type: 'stock' as const,
      potentialReturn: 12,
      risk: 'low' as const,
      reasoning: 'Stable dividend stock with consistent growth. AI integration potential.'
    },
    {
      symbol: 'NVDA',
      name: 'NVIDIA',
      type: 'stock' as const,
      potentialReturn: 35,
      risk: 'medium' as const,
      reasoning: 'AI chip demand continues to surge. Data center growth strong.'
    },
    {
      symbol: 'GOOGL',
      name: 'Alphabet',
      type: 'stock' as const,
      potentialReturn: 15,
      risk: 'low' as const,
      reasoning: 'Search dominance + cloud growth. Undervalued compared to peers.'
    },
    {
      symbol: 'MSFT',
      name: 'Microsoft',
      type: 'stock' as const,
      potentialReturn: 18,
      risk: 'low' as const,
      reasoning: 'Azure growth + AI integration. Stable enterprise business.'
    },
    {
      symbol: 'AMZN',
      name: 'Amazon',
      type: 'stock' as const,
      potentialReturn: 22,
      risk: 'medium' as const,
      reasoning: 'AWS recovery + retail efficiency improvements.'
    },
    {
      symbol: 'TSLA',
      name: 'Tesla',
      type: 'stock' as const,
      potentialReturn: 30,
      risk: 'high' as const,
      reasoning: 'FSD progress + energy business growth. Volatile but high potential.'
    },
    {
      symbol: 'SOL',
      name: 'Solana',
      type: 'crypto' as const,
      potentialReturn: 40,
      risk: 'high' as const,
      reasoning: 'Fastest growing L1. Strong DeFi and NFT ecosystem.'
    },
    {
      symbol: 'META',
      name: 'Meta Platforms',
      type: 'stock' as const,
      potentialReturn: 20,
      risk: 'medium' as const,
      reasoning: 'Metaverse bet + AI integration. Cost cutting improving margins.'
    }
  ];
}
