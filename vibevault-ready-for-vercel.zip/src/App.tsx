import { StoreProvider, useStore, useNavigation } from '@/store';
import { Toaster } from '@/components/ui/sonner';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/cart/CartDrawer';
import Home from '@/pages/Home';
import Shop from '@/pages/Shop';
import ProductDetail from '@/pages/ProductDetail';
import Checkout from '@/pages/Checkout';
import Login from '@/pages/Login';
import Account from '@/pages/Account';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminProducts from '@/pages/admin/AdminProducts';
import AdminOrders from '@/pages/admin/AdminOrders';
import AdminMarket from '@/pages/admin/AdminMarket';
import AdminTrade from '@/pages/admin/AdminTrade';
import './App.css';

function AppContent() {
  const { state } = useStore();
  const { currentPage } = useNavigation();

  const renderPage = () => {
    if (state.isAdmin) {
      switch (currentPage) {
        case 'admin':
          return <AdminDashboard />;
        case 'admin-products':
          return <AdminProducts />;
        case 'admin-orders':
          return <AdminOrders />;
        case 'admin-market':
          return <AdminMarket />;
        case 'admin-trade':
          return <AdminTrade />;
        default:
          return <AdminDashboard />;
      }
    }

    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'shop':
        return <Shop />;
      case 'product':
        return <ProductDetail />;
      case 'checkout':
        return <Checkout />;
      case 'login':
        return <Login />;
      case 'account':
        return <Account />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="container-modern "min-h-screen bg-black text-white">
      <Navbar />
      <CartDrawer />
      <main>{renderPage()}</main>
      <Footer />
      <Toaster position="top-right" richColors />
    </div>
  );
}

function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}

export default App;
