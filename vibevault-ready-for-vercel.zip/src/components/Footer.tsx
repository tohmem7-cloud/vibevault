import { Instagram, Twitter, Facebook, Mail, MapPin } from 'lucide-react';
import { useNavigation } from '@/store';

export default function Footer() {
  const { navigate } = useNavigation();
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    shop: [
      { name: 'All Products', action: () => navigate('shop') },
      { name: 'Hoodies', action: () => navigate('shop') },
      { name: 'Pants', action: () => navigate('shop') },
      { name: 'Tracksuits', action: () => navigate('shop') },
      { name: 'Colognes', action: () => navigate('shop') },
    ],
    support: [
      { name: 'Contact Us', action: () => {} },
      { name: 'FAQs', action: () => {} },
      { name: 'Shipping Info', action: () => {} },
      { name: 'Returns', action: () => {} },
      { name: 'Size Guide', action: () => {} },
    ],
    company: [
      { name: 'About Us', action: () => {} },
      { name: 'Careers', action: () => {} },
      { name: 'Press', action: () => {} },
      { name: 'Sustainability', action: () => {} },
    ],
  };

  return (
    <footer className="bg-zinc-950 border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <button onClick={() => navigate('home')} className="inline-block">
              <span className="font-display text-4xl tracking-wider bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent">
                VIBEVAULT
              </span>
            </button>
            <p className="mt-4 text-zinc-400 text-sm max-w-sm">
              Premium streetwear and sneakers. Curated drops, exclusive releases, 
              and the finest selection of urban fashion.
            </p>
            
            {/* Contact Info */}
            <div className="mt-6 space-y-2">
              <div className="flex items-center text-zinc-400 text-sm">
                <Mail className="h-4 w-4 mr-2" />
                <span>tohmem7@gmail.com</span>
              </div>
              <div className="flex items-center text-zinc-400 text-sm">
                <MapPin className="h-4 w-4 mr-2" />
                <span>Canada</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-4 mt-6">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-zinc-900 rounded-full text-zinc-400 hover:text-purple-400 hover:bg-zinc-800 transition-all"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-zinc-900 rounded-full text-zinc-400 hover:text-purple-400 hover:bg-zinc-800 transition-all"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 bg-zinc-900 rounded-full text-zinc-400 hover:text-purple-400 hover:bg-zinc-800 transition-all"
              >
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Shop Links */}
          <div>
            <h3 className="text-white font-medium mb-4">Shop</h3>
            <ul className="space-y-2">
              {footerLinks.shop.map((link) => (
                <li key={link.name}>
                  <button
                    onClick={link.action}
                    className="text-zinc-400 text-sm hover:text-purple-400 transition-colors"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h3 className="text-white font-medium mb-4">Support</h3>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <button
                    onClick={link.action}
                    className="text-zinc-400 text-sm hover:text-purple-400 transition-colors"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="text-white font-medium mb-4">Company</h3>
            <ul className="space-y-2">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <button
                    onClick={link.action}
                    className="text-zinc-400 text-sm hover:text-purple-400 transition-colors"
                  >
                    {link.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-zinc-900 flex flex-col md:flex-row justify-between items-center">
          <p className="text-zinc-500 text-sm">
            © {currentYear} VibeVault. All rights reserved.
          </p>
          <div className="flex items-center space-x-6 mt-4 md:mt-0">
            <button className="text-zinc-500 text-sm hover:text-purple-400 transition-colors">
              Privacy Policy
            </button>
            <button className="text-zinc-500 text-sm hover:text-purple-400 transition-colors">
              Terms of Service
            </button>
            <button className="text-zinc-500 text-sm hover:text-purple-400 transition-colors">
              Cookies
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
