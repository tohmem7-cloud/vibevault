import { useState } from 'react';
import { Plus, Minus, ShoppingBag, Trash2, ArrowRight } from 'lucide-react';
import { useCart, useNavigation } from '@/store';
import { formatPrice } from '@/utils/helpers';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';

export default function CartDrawer() {
  const [isOpen, setIsOpen] = useState(false);
  const { cart, cartCount, cartTotal, removeFromCart, updateQuantity } = useCart();
  const { navigate } = useNavigation();

  const handleCheckout = () => {
    setIsOpen(false);
    navigate('checkout');
  };

  if (cartCount === 0) {
    return (
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <button className="p-2 text-white hover:text-purple-400 transition-colors relative">
            <ShoppingBag className="h-5 w-5" />
          </button>
        </SheetTrigger>
        <SheetContent className="bg-zinc-900 border-zinc-800 w-full sm:max-w-md">
          <SheetHeader>
            <SheetTitle className="text-white text-xl font-display">Your Cart</SheetTitle>
          </SheetHeader>
          <div className="flex flex-col items-center justify-center h-[60vh] text-center">
            <ShoppingBag className="h-16 w-16 text-zinc-600 mb-4" />
            <p className="text-zinc-400 text-lg mb-2">Your cart is empty</p>
            <p className="text-zinc-500 text-sm mb-6">Add some items to get started</p>
            <Button
              onClick={() => {
                setIsOpen(false);
                navigate('shop');
              }}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              Shop Now
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <button className="p-2 text-white hover:text-purple-400 transition-colors relative">
          <ShoppingBag className="h-5 w-5" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </button>
      </SheetTrigger>
      <SheetContent className="bg-zinc-900 border-zinc-800 w-full sm:max-w-md overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="text-white text-xl font-display flex items-center justify-between">
            Your Cart ({cartCount} items)
          </SheetTitle>
        </SheetHeader>

        <div className="mt-6 space-y-4">
          {cart.map((item, index) => (
            <div
              key={`${item.product.id}-${item.size}-${item.color}-${index}`}
              className="flex gap-4 p-4 bg-zinc-800/50 rounded-lg"
            >
              <img
                src={item.product.image}
                alt={item.product.name}
                className="w-20 h-20 object-cover rounded-md"
              />
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-white font-medium text-sm line-clamp-1">{item.product.name}</p>
                    <p className="text-zinc-400 text-xs">{item.product.brand}</p>
                    <p className="text-zinc-500 text-xs mt-1">
                      Size: {item.size} {item.ml && `• ${item.ml}ml`}
                    </p>
                    <p className="text-zinc-500 text-xs">Color: {item.color}</p>
                  </div>
                  <button
                    onClick={() => removeFromCart(item.product.id)}
                    className="text-zinc-500 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
                <div className="flex justify-between items-center mt-3">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQuantity(item.product.id, Math.max(1, item.quantity - 1))}
                      className="p-1 bg-zinc-700 rounded hover:bg-zinc-600 transition-colors"
                    >
                      <Minus className="h-3 w-3" />
                    </button>
                    <span className="text-white text-sm w-6 text-center">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                      className="p-1 bg-zinc-700 rounded hover:bg-zinc-600 transition-colors"
                    >
                      <Plus className="h-3 w-3" />
                    </button>
                  </div>
                  <p className="text-purple-400 font-medium">
                    {formatPrice(item.product.price * item.quantity)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-6 border-t border-zinc-800">
          <div className="space-y-2 mb-4">
            <div className="flex justify-between text-zinc-400">
              <span>Subtotal</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
            <div className="flex justify-between text-zinc-400">
              <span>Shipping</span>
              <span className="text-green-400">FREE (Preorder)</span>
            </div>
            <div className="flex justify-between text-white text-lg font-medium pt-2 border-t border-zinc-800">
              <span>Total</span>
              <span>{formatPrice(cartTotal)}</span>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              onClick={handleCheckout}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-medium py-6"
            >
              Checkout
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setIsOpen(false);
                navigate('shop');
              }}
              className="w-full border-zinc-700 text-white hover:bg-zinc-800"
            >
              Continue Shopping
            </Button>
          </div>

          <p className="text-center text-zinc-500 text-xs mt-4">
            All preorders ship by February 23rd with FREE shipping
          </p>
        </div>
      </SheetContent>
    </Sheet>
  );
}
