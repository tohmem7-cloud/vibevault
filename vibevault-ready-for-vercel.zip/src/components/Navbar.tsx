import { useState, useEffect } from 'react';
import { Search, ShoppingBag, Menu, X, User, Heart, ChevronDown } from 'lucide-react';
import { useCart, useAuth, useNavigation } from '@/store';
import { categories } from '@/data/products';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { cartCount } = useCart();
  const { user, isAdmin, logout } = useAuth();
  const { navigate } = useNavigation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate('shop');
      setIsSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-black/90 backdrop-blur-lg py-3'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <button onClick={() => navigate('home')} className="flex items-center">
              <span className="font-display text-3xl tracking-wider bg-gradient-to-r from-purple-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent">
                VIBEVAULT
              </span>
            </button>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => navigate('home')}
                className={`text-sm font-medium transition-colors hover:text-purple-400 ${
                  !isAdmin ? 'text-purple-400' : 'text-white'
                }`}
              >
                Home
              </button>
              
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center text-sm font-medium text-white hover:text-purple-400 transition-colors">
                  Shop <ChevronDown className="ml-1 h-4 w-4" />
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-zinc-900 border-zinc-800 w-48">
                  <DropdownMenuItem onClick={() => navigate('shop')} className="text-white hover:bg-zinc-800 cursor-pointer">
                    All Products
                  </DropdownMenuItem>
                  {categories.map((cat) => (
                    <DropdownMenuItem
                      key={cat.id}
                      onClick={() => navigate('shop')}
                      className="text-white hover:bg-zinc-800 cursor-pointer"
                    >
                      {cat.name}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              {isAdmin && (
                <DropdownMenu>
                  <DropdownMenuTrigger className="flex items-center text-sm font-medium text-purple-400 hover:text-purple-300 transition-colors">
                    Admin <ChevronDown className="ml-1 h-4 w-4" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="bg-zinc-900 border-zinc-800 w-48">
                    <DropdownMenuItem onClick={() => navigate('admin')} className="text-white hover:bg-zinc-800 cursor-pointer">
                      Dashboard
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('admin-products')} className="text-white hover:bg-zinc-800 cursor-pointer">
                      Products
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('admin-orders')} className="text-white hover:bg-zinc-800 cursor-pointer">
                      Orders
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('admin-market')} className="text-white hover:bg-zinc-800 cursor-pointer">
                      Market
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('admin-trade')} className="text-white hover:bg-zinc-800 cursor-pointer">
                      Trade
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            {/* Right Actions */}
            <div className="flex items-center space-x-4">
              {/* Search */}
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="p-2 text-white hover:text-purple-400 transition-colors"
              >
                <Search className="h-5 w-5" />
              </button>

              {/* Wishlist */}
              {user && (
                <button
                  onClick={() => navigate('account')}
                  className="p-2 text-white hover:text-purple-400 transition-colors hidden sm:block"
                >
                  <Heart className="h-5 w-5" />
                </button>
              )}

              {/* Account / Login */}
              {user ? (
                <button
                  onClick={() => navigate('account')}
                  className="p-2 text-white hover:text-purple-400 transition-colors hidden sm:block"
                >
                  <User className="h-5 w-5" />
                </button>
              ) : (
                <button
                  onClick={() => navigate('login')}
                  className="hidden sm:flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-sm font-medium rounded-lg hover:from-purple-600 hover:to-pink-600 transition-all"
                >
                  <User className="h-4 w-4" />
                  Login / Sign Up
                </button>
              )}

              {/* Cart */}
              <button
                onClick={() => {}}
                className="p-2 text-white hover:text-purple-400 transition-colors relative"
              >
                <ShoppingBag className="h-5 w-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Mobile Menu Toggle */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 text-white hover:text-purple-400 transition-colors md:hidden"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        {isSearchOpen && (
          <div className="absolute top-full left-0 right-0 bg-zinc-900 border-b border-zinc-800 p-4 animate-slide-up">
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search products..."
                  className="w-full bg-zinc-800 text-white px-4 py-3 pl-12 rounded-lg focus:ring-2 focus:ring-purple-500"
                  autoFocus
                />
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-zinc-400" />
                <button
                  type="button"
                  onClick={() => setIsSearchOpen(false)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </form>
          </div>
        )}
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-black pt-20 md:hidden">
          <div className="px-4 py-8 space-y-6">
            <button
              onClick={() => {
                navigate('home');
                setIsMobileMenuOpen(false);
              }}
              className="block text-2xl font-display text-white hover:text-purple-400 transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => {
                navigate('shop');
                setIsMobileMenuOpen(false);
              }}
              className="block text-2xl font-display text-white hover:text-purple-400 transition-colors"
            >
              Shop
            </button>
            
            <div className="pt-6 border-t border-zinc-800">
              <p className="text-zinc-500 text-sm mb-4">Categories</p>
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    navigate('shop');
                    setIsMobileMenuOpen(false);
                  }}
                  className="block text-lg text-white hover:text-purple-400 transition-colors py-2"
                >
                  {cat.name}
                </button>
              ))}
            </div>

            {isAdmin && (
              <div className="pt-6 border-t border-zinc-800">
                <p className="text-purple-400 text-sm mb-4">Admin</p>
                <button onClick={() => { navigate('admin'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                  Dashboard
                </button>
                <button onClick={() => { navigate('admin-products'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                  Products
                </button>
                <button onClick={() => { navigate('admin-orders'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                  Orders
                </button>
                <button onClick={() => { navigate('admin-market'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                  Market
                </button>
                <button onClick={() => { navigate('admin-trade'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                  Trade
                </button>
              </div>
            )}

            <div className="pt-6 border-t border-zinc-800">
              {user ? (
                <>
                  <button onClick={() => { navigate('account'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                    My Account
                  </button>
                  <button
                    onClick={() => {
                      logout();
                      setIsMobileMenuOpen(false);
                    }}
                    className="block text-lg text-red-400 hover:text-red-300 py-2"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <button onClick={() => { navigate('login'); setIsMobileMenuOpen(false); }} className="block text-lg text-white hover:text-purple-400 py-2">
                  Login / Sign Up
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
