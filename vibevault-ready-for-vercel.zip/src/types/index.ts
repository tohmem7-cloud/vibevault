export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  category: 'hoodies' | 'pants' | 'tracksuits' | 'colognes';
  subcategory?: string;
  image: string;
  images: string[];
  sizes: string[];
  colors: { name: string; hex: string; image?: string }[];
  description: string;
  details: string[];
  inStock: boolean;
  stockCount: number;
  isPreorder?: boolean;
  preorderShipDate?: string;
  rating: number;
  reviewCount: number;
  isBestseller?: boolean;
  isNew?: boolean;
  scentNotes?: string[];
  mlOptions?: number[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  size: string;
  color: string;
  ml?: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  shipping: number;
  tax: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
  shippingAddress: Address;
  paymentMethod: string;
  customerEmail: string;
  trackingNumber?: string;
}

export interface Address {
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
  phone: string;
}

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  orders: Order[];
  wishlist: string[];
  addresses: Address[];
}

export interface FilterState {
  brands: string[];
  categories: string[];
  priceRange: [number, number];
  sizes: string[];
  colors: string[];
  sortBy: 'price-low' | 'price-high' | 'newest' | 'popular' | 'rating';
}

export interface TrendingItem {
  name: string;
  popularity: number;
  chartData: { date: string; value: number }[];
  category: string;
}

export interface TradeRecommendation {
  symbol: string;
  name: string;
  type: 'crypto' | 'stock';
  potentialReturn: number;
  risk: 'low' | 'medium' | 'high';
  reasoning: string;
}
