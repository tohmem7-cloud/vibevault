import React, { createContext, useContext, useReducer, type ReactNode } from 'react';
import type { CartItem, User, Order, FilterState } from '@/types';

interface StoreState {
  cart: CartItem[];
  selectedProductId: string | null;
  user: User | null;
  isAdmin: boolean;
  orders: Order[];
  filters: FilterState;
  wishlist: string[];
  currentPage: string;
}

type Action =
  | { type: 'SET_PRODUCT'; payload: string }

  | { type: 'ADD_TO_CART'; payload: CartItem }
  | { type: 'REMOVE_FROM_CART'; payload: string }
  | { type: 'UPDATE_CART_QUANTITY'; payload: { id: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_ADMIN'; payload: boolean }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_FILTERS'; payload: Partial<FilterState> }
  | { type: 'RESET_FILTERS' }
  | { type: 'TOGGLE_WISHLIST'; payload: string }
  | { type: 'SET_WISHLIST'; payload: string[] }
  | { type: 'SET_PAGE'; payload: string };

const initialState: StoreState = {
  cart: [],
  selectedProductId: null,
  user: null,
  isAdmin: false,
  orders: [],
  filters: {
    brands: [],
    categories: [],
    priceRange: [0, 1000],
    sizes: [],
    colors: [],
    sortBy: 'newest'
  },
  wishlist: [],
  currentPage: 'home'
};

function storeReducer(state: StoreState, action: Action): StoreState {
  switch (action.type) {
    case 'ADD_TO_CART': {
      const existingItem = state.cart.find(
        item => 
          item.product.id === action.payload.product.id && 
          item.size === action.payload.size && 
          item.color === action.payload.color
      );
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(item =>
            item === existingItem
              ? { ...item, quantity: item.quantity + action.payload.quantity }
              : item
          )
        };
      }
      return { ...state, cart: [...state.cart, action.payload] };
    }
    case 'REMOVE_FROM_CART':
      return { ...state, cart: state.cart.filter(item => item.product.id !== action.payload) };
    case 'UPDATE_CART_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.product.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        )
      };
    case 'CLEAR_CART':
      return { ...state, cart: [] };
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_ADMIN':
      return { ...state, isAdmin: action.payload };
    case 'ADD_ORDER':
      return { ...state, orders: [...state.orders, action.payload] };
    case 'UPDATE_FILTERS':
      return { ...state, filters: { ...state.filters, ...action.payload } };
    case 'RESET_FILTERS':
      return {
        ...state,
        filters: initialState.filters
      };
    case 'TOGGLE_WISHLIST': {
      const exists = state.wishlist.includes(action.payload);
      if (exists) {
        return { ...state, wishlist: state.wishlist.filter(id => id !== action.payload) };
      }
      return { ...state, wishlist: [...state.wishlist, action.payload] };
    }
    case 'SET_WISHLIST':
      return { ...state, wishlist: action.payload };
    case 'SET_PAGE':
      return { ...state, currentPage: action.payload };
    case 'SET_PRODUCT':
      return { ...state, selectedProductId: action.payload };
    default:
      return state;
  }
}

const StoreContext = createContext<{
  state: StoreState;
  dispatch: React.Dispatch<Action>;
} | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(storeReducer, initialState);
  return (
    <StoreContext.Provider value={{ state, dispatch }}>
      {children}
    </StoreContext.Provider>
  );
}

export function useStore() {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}

// Helper hooks
export function useCart() {
  const { state, dispatch } = useStore();
  return {
    cart: state.cart,
    cartCount: state.cart.reduce((sum, item) => sum + item.quantity, 0),
    cartTotal: state.cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0),
    addToCart: (item: CartItem) => dispatch({ type: 'ADD_TO_CART', payload: item }),
    removeFromCart: (id: string) => dispatch({ type: 'REMOVE_FROM_CART', payload: id }),
    updateQuantity: (id: string, quantity: number) =>
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { id, quantity } }),
    clearCart: () => dispatch({ type: 'CLEAR_CART' })
  };
}

export function useAuth() {
  const { state, dispatch } = useStore();
  return {
    user: state.user,
    isAdmin: state.isAdmin,
    setUser: (user: User | null) => dispatch({ type: 'SET_USER', payload: user }),
    setAdmin: (isAdmin: boolean) => dispatch({ type: 'SET_ADMIN', payload: isAdmin }),
    login: (email: string, password: string) => {
      if (email === 'tohmem7@gmail.com' && password === 'mohamad7') {
        dispatch({ type: 'SET_ADMIN', payload: true });
        return { success: true, isAdmin: true };
      }
      dispatch({
        type: 'SET_USER',
        payload: {
          id: '1',
          email,
          firstName: 'User',
          lastName: 'Name',
          orders: [],
          wishlist: [],
          addresses: []
        }
      });
      return { success: true, isAdmin: false };
    },
    logout: () => {
      dispatch({ type: 'SET_USER', payload: null });
      dispatch({ type: 'SET_ADMIN', payload: false });
    }
  };
}

export function useFilters() {
  const { state, dispatch } = useStore();
  return {
    filters: state.filters,
    updateFilters: (filters: Partial<FilterState>) =>
      dispatch({ type: 'UPDATE_FILTERS', payload: filters }),
    resetFilters: () => dispatch({ type: 'RESET_FILTERS' })
  };
}

export function useWishlist() {
  const { state, dispatch } = useStore();
  return {
    wishlist: state.wishlist,
    toggleWishlist: (id: string) => dispatch({ type: 'TOGGLE_WISHLIST', payload: id }),
    isInWishlist: (id: string) => state.wishlist.includes(id)
  };
}

export function useNavigation() {
  const { state, dispatch } = useStore();
  return {
    currentPage: state.currentPage,
    navigate: (page: string) => {
      dispatch({ type: 'SET_PAGE', payload: page });
      window.scrollTo(0, 0);
    }
  };
}
